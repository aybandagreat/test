<?php session_start(); ?>

<?php
    if (isset($_SESSION['admin']) && !empty($_SESSION['admin'])) {
        $adminid = $_SESSION['adminid'];
        $admin = $_SESSION['admin'];
        require 'dbconnect.php';
    }
    else if (!isset($_SESSION['admin']) || empty($_SESSION['admin'])) {
        header("Location: admin-login.php?error=invalidaccess");
        exit();
    }
?>


<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="admin-style.css">
        <title>Entrance Exam | Admin</title>
    </head>
    <body>
        <div class="admin-container">
            
            <?php include_once "admin-sidebar.inc.php"; ?>

            <div class="content">
                <div class="search">
                    <h4>Exam Results</h4>
                    <form method="GET">
                        <input type="text" name="searchToken" placeholder="Search Code" >
                        <input type="text" name="searchName" placeholder="Search Name" >
                        <button type="submit">Search</button>
                    </form>
                </div>
                <table id="examineeTable">
                    <tr>
                        <th onclick="sortTable(0)">Code</th>
                        <th onclick="sortTable(1)">Examinee Name</th>
                        <th onclick="sortTable(2)">Rating (%)</th>
                    </tr>
                    <?php

                        if (isset($_GET['searchToken']) && !empty($_GET['searchToken'])) {
                            $searchtoken = trim($_GET['searchToken']);
                            $sql = "SELECT * FROM examinee WHERE token = '$searchtoken' OR token LIKE '%$searchtoken%'";
                        }
                        else if (isset($_GET['searchName']) && !empty($_GET['searchName'])) {
                            $searchname = trim($_GET['searchName']);
                            $sql = "SELECT * FROM examinee WHERE firstname = '$searchname' OR lastname = '$searchname' OR firstname LIKE '%$searchname%' OR lastname LIKE '%$searchname%' ORDER BY lastname, firstname ASC";
                        }
                        else {
                            $sql = "SELECT * FROM examinee ORDER BY lastname, firstname ASC";
                        }

                        $stmt = mysqli_stmt_init($conn);
                        mysqli_stmt_prepare($stmt, $sql);
                        mysqli_stmt_execute($stmt);
                        $result = mysqli_stmt_get_result($stmt);
                        while ($row = mysqli_fetch_assoc($result)) {

                            $eid = $row['id'];

                            $sql2 = "SELECT * FROM exam_attempt WHERE examinee_id = '$eid' AND attempt = '1'";
                            mysqli_stmt_prepare($stmt, $sql2);
                            mysqli_stmt_execute($stmt);
                            mysqli_stmt_store_result($stmt);
                            $check2 = mysqli_stmt_num_rows($stmt);

                            if ($check2 == 0) {
                                $status = "<td class='center' style='color: red;'>Not yet answered</td>";
                            }
                            else if ($check2 > 0) {
                                $sql2 = "SELECT * FROM exam_attempt WHERE examinee_id = '$eid' AND attempt = '0'";
                                mysqli_stmt_prepare($stmt, $sql2);
                                mysqli_stmt_execute($stmt);
                                mysqli_stmt_store_result($stmt);
                                $check2 = mysqli_stmt_num_rows($stmt);
                                if ($check2 == 0) {
                                    $totalItems = 0;
                                    $sql2 = "SELECT * FROM subject";
                                    mysqli_stmt_prepare($stmt, $sql2);
                                    mysqli_stmt_execute($stmt);
                                    $result2 = mysqli_stmt_get_result($stmt);
                                    while ($row2 = mysqli_fetch_assoc($result2)) {
                                        $totalItems = $totalItems + $row2['items'];
                                    }
                                    $totalCorrect = 0;
                                    $sql2 = "SELECT * FROM exam_result WHERE examinee_id = '$eid'";
                                    mysqli_stmt_prepare($stmt, $sql2);
                                    mysqli_stmt_execute($stmt);
                                    $result2 = mysqli_stmt_get_result($stmt);
                                    while ($row2 = mysqli_fetch_assoc($result2)) {
                                        $totalCorrect = $totalCorrect + $row2['correct_answers'];
                                    }

                                    $rating = round($totalCorrect * (100/$totalItems) , 2);

                                    $status = "<td class='center' style='color: black;'>" . $rating . "%</td>";

                                }
                                else if ($check2 > 0) {
                                    $status = "<td class='center' style='color: orange;'>Answering</td>";
                                }
                            }
                            else {
                                $status = "<td class='center' style='color: black;'>TBA</td>";
                            }
                            ?>

                            <tr class="viewExmainee" onclick="(location.href = 'view-examinee.php?examinee=<?php echo $eid; ?>')">
                                <td class="center"><?php echo $row['token']; ?></td>
                                <td class="left" style="text-transform: uppercase;"><?php echo $row['lastname'] . ", " . $row['firstname']; ?></td>
                                <?php echo $status; ?>
                            </tr>
                            <?php
                        }
                    ?>
                </table>
            </div>
        </div>

        
<script>
        window.onclick = function(event) {
            if (event.target == editmodal) {
                editmodal.classList.remove('visible');
            }
            if (event.target == modal) {
                alert("Please use the close button to close this modal.");
            }
            if (event.target == errormodal) {
                errormodal.style.display = 'none';
            }
            if (event.target == editmodal) {
                editmodal.classList.remove('visible');
            }
            if (event.target == coursemodal) {
                coursemodal.classList.remove('visible');
            }
        }

        function sortTable(n) {
          var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
          table = document.getElementById("examineeTable");
          switching = true;
          // Set the sorting direction to ascending:
          dir = "asc";
          /* Make a loop that will continue until
          no switching has been done: */
          while (switching) {
            // Start by saying: no switching is done:
            switching = false;
            rows = table.rows;
            /* Loop through all table rows (except the
            first, which contains table headers): */
            for (i = 1; i < (rows.length - 1); i++) {
              // Start by saying there should be no switching:
              shouldSwitch = false;
              /* Get the two elements you want to compare,
              one from current row and one from the next: */
              x = rows[i].getElementsByTagName("TD")[n];
              y = rows[i + 1].getElementsByTagName("TD")[n];
              /* Check if the two rows should switch place,
              based on the direction, asc or desc: */
              if (dir == "asc") {
                if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
                  // If so, mark as a switch and break the loop:
                  shouldSwitch = true;
                  break;
                }
              } else if (dir == "desc") {
                if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
                  // If so, mark as a switch and break the loop:
                  shouldSwitch = true;
                  break;
                }
              }
            }
            if (shouldSwitch) {
              /* If a switch has been marked, make the switch
              and mark that a switch has been done: */
              rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
              switching = true;
              // Each time a switch is done, increase this count by 1:
              switchcount ++;
            } else {
              /* If no switching has been done AND the direction is "asc",
              set the direction to "desc" and run the while loop again. */
              if (switchcount == 0 && dir == "asc") {
                dir = "desc";
                switching = true;
              }
            }
          }
        }
    </script>

    </body>
    
</html>

