<?php
    if (isset($_POST['add-button'])) {
        
        if (empty($_POST['newFirstname']) || empty($_POST['newLastname']) || empty($_POST['newAddress']) || empty($_POST['newBirthdate']) || empty($_POST['newEmail']) || empty($_POST['newPassword'])) {
            header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=emptyinputs");
            exit();
        }
        else if (!empty($_POST['newFirstname']) && !empty($_POST['newLastname']) && !empty($_POST['newAddress']) && !empty($_POST['newBirthdate']) && !empty($_POST['newEmail']) && !empty($_POST['newPassword'])) {

            require 'dbconnect.php';

            $email = trim($_POST['newEmail']);
            $password = $_POST['newPassword'];
            $fname = strtolower(trim($_POST['newFirstname']));
            $lname = strtolower(trim($_POST['newLastname']));
            $address = trim($_POST['newAddress']);
            $bdate = $_POST['newBirthdate'];
            $token = rand(000001, 999999);
            $existingToken = true;

            
            $sql = "SELECT firstname,lastname FROM examinee WHERE firstname=? AND lastname=? OR email = ?";
            $stmt = mysqli_stmt_init($conn);

            if (!mysqli_stmt_prepare($stmt, $sql)) {
                header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=sqlerror");
                exit();
            }
            else {
                mysqli_stmt_bind_param($stmt, "sss", $fname, $lname, $email);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_store_result($stmt);

                $resultcheck = mysqli_stmt_num_rows($stmt);
                if ($resultcheck > 0) {
                    header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=existingexaminee");
                    exit();
                }
                else {

                    //checks if token exists & create a new one until generated token is unique
                    while ($existingToken == true) {
                        $sql = "SELECT token FROM examinee WHERE token=?";
                        $stmt = mysqli_stmt_init($conn);
                        mysqli_stmt_prepare($stmt, $sql);
                        mysqli_stmt_bind_param($stmt, "i", $token);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_store_result($stmt);
                        $resultcheck = mysqli_stmt_num_rows($stmt);

                        if ($resultcheck > 0) {
                            $existingToken = true;
                            $token = rand(000001, 999999);
                        }
                        else if ($resultcheck == 0) {
                            $existingToken = false;
                        }
                    }

                    $hashpass = password_hash($password, PASSWORD_DEFAULT);

                    $sql = "INSERT INTO examinee (firstname, lastname, address, birthdate, token, email, password) VALUES (?, ?, ?, ?, ?, ?, ?)";
                    $stmt = mysqli_stmt_init($conn);

                    if (!mysqli_stmt_prepare($stmt, $sql)) {
                        header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=sqlerror");
                        exit();
                    }
                    else {
                        mysqli_stmt_bind_param($stmt, "ssssiss", $fname, $lname, $address, $bdate, $token, $email, $hashpass);
                        mysqli_stmt_execute($stmt);

                        $examineeid = mysqli_stmt_insert_id($stmt);

                        $sql = "SELECT * FROM subject";
                        mysqli_stmt_prepare($stmt, $sql);
                        mysqli_stmt_execute($stmt);
                        $result1 = mysqli_stmt_get_result($stmt);

                        while ($row = mysqli_fetch_assoc($result1)) {
                            $subjid = $row['id'];
                            $sql2 = "INSERT INTO exam_attempt (subject_id, examinee_id) VALUES (? ,?)";
                            mysqli_stmt_prepare($stmt, $sql2);
                            mysqli_stmt_bind_param($stmt, "ii", $subjid, $examineeid);
                            mysqli_stmt_execute($stmt);
                        }

                        header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?msg=success&email=" . $email . "&token=" . $token);
                        exit();
                    }
                }
            }
        }
    }
    else if (!isset($_POST['add-button'])) {
         header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=invalidaccess");
        exit();
    }
    else {
        header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0]);
        exit();
    }