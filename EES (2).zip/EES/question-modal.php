<?php

    require 'dbconnect.php';

    if (isset($_POST['question']) && !empty($_POST['question'])) {
        $subjId = $_POST['subject'];
        $id = $_POST['question'];
        $sql = "SELECT * FROM questions WHERE id = $id";
        $stmt = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($stmt, $sql);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        while ($row = mysqli_fetch_assoc($result)) {
            ?>
                <div id="questionmodal">
                    <form action="edit-question.sql.php" method="POST">
                        <h4>EDIT QUESTION</h4>
                        <div>
                            <label for="editQuestion">Question</label>
                            <input type="text" name="editQuestion" id="editQuestion" required value="<?php echo $row['question']; ?>">
                        </div>
                        <div>
                            <label for="editA">Choice A</label>
                            <?php
                                if ($row['choice1'] == $row['answer']) {
                                    ?><input type="text" name="editA" id="editA" class="correctAnswer" required value="<?php echo $row['choice1']; ?>"> <?php
                                }
                                else {
                                    ?><input type="text" name="editA" id="editA" required value="<?php echo $row['choice1']; ?>"><?php
                                }
                            ?>
                        </div>
                        <div>
                            <label for="editB">Choice B</label>
                            <?php
                                if ($row['choice2'] == $row['answer']) {
                                    ?><input type="text" name="editB" id="editB" class="correctAnswer" required value="<?php echo $row['choice2']; ?>"><?php
                                }
                                else {
                                    ?><input type="text" name="editB" id="editB" required value="<?php echo $row['choice2']; ?>"><?php
                                }
                            ?>
                            
                        </div>
                        <div>
                            <label for="editC">Choice C</label>
                            <?php
                                if ($row['choice3'] == $row['answer']) {
                                    ?><input type="text" name="editC" id="editC" class="correctAnswer" required value="<?php echo $row['choice3']; ?>"><?php
                                }
                                else {
                                    ?><input type="text" name="editC" id="editC" required value="<?php echo $row['choice3']; ?>"><?php
                                }
                            ?>
                            
                        </div>
                        <div>
                            <label for="editD">Choice D</label>
                            <?php
                                if ($row['choice4'] == $row['answer']) {
                                    ?><input type="text" name="editD" id="editD" class="correctAnswer" required value="<?php echo $row['choice4']; ?>"><?php
                                }
                                else {
                                    ?><input type="text" name="editD" id="editD" required value="<?php echo $row['choice4']; ?>"><?php
                                }
                            ?>
                            
                        </div>
                        <div>
                            <label>New Answer</label>
                            <select name="editAnswer" required style="width: 100%;">
                                <option selected disabled value="">Select a new answer</option>
                                <option value="1">Choice A</option>
                                <option value="2">Choice B</option>
                                <option value="3">Choice C</option>
                                <option value="4">Choice D</option>
                            </select>
                        </div>
                        <input type='hidden' name='subjectid' value='<?php echo $subjId; ?>'>
                        <input type="hidden" name="questionId" id="questionId" value="<?php echo $row['id']; ?>">
                        <div class="button-container">
                            <button type="button" onclick="closeModal()">CANCEL</button>
                            <button type="submit" name="question-button">EDIT</button>
                        </div>
                    </form>
                </div>
            <?php
        }
    }

?>

