<?php session_start(); ?>

<?php
    if (isset($_SESSION['admin']) && !empty($_SESSION['admin'])) {
        $adminid = $_SESSION['adminid'];
        $admin = $_SESSION['admin'];
        require 'dbconnect.php';
    }
    else if (!isset($_SESSION['admin']) || empty($_SESSION['admin'])) {
        header("Location: admin-login.php?error=invalidaccess");
        exit();
    }
?>


<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="admin-style.css">
        <title>Entrance Exam | Admin</title>
    </head>
    <body>
        <div class="admin-container">
            
            <?php include_once "admin-sidebar.inc.php"; ?>

            <div class="content">
                <div class="search">
                    <h4>Subject List</h4>
                    <form method="GET">
                        <input type="text" name="searchSubject" placeholder="Subject Name">
                        <button type="submit">Search</button>
                    </form>
                </div>
                <table class="course-table" id="examineeTable">
                    <tr>
                        <th onclick="sortTable(0)">Subject Name</th>
                        <th onclick="sortTable(1)">Total Items</th>
                        <th onclick="sortTable(2)">Time Limit (Minutes)</th>
                        <th onclick="sortTable(3)">Passing Score (Percentage)</th>
                        <th class="fixedWidth"></th>
                    </tr>

                    <?php
                       if (isset($_GET['searchSubject']) && !empty($_GET['searchSubject'])) {
                            $subject = $_GET['searchSubject'];
                            $sql = "SELECT * FROM subject WHERE description = '$subject' OR description LIKE '%$subject%' ORDER BY description ASC";
                            $stmt = mysqli_stmt_init($conn);
                            mysqli_stmt_prepare($stmt, $sql);
                            mysqli_stmt_execute($stmt);
                            $result = mysqli_stmt_get_result($stmt);

                            while ($row = mysqli_fetch_assoc($result)) {
                                ?>
                                <tr>
                                    <td class="left"><?php echo $row['description']; ?></td>
                                    <td class="center"><?php echo $row['items']; ?></td>
                                    <td class="center"><?php echo $row['time_limit'] . " Minutes"; ?></td>
                                    <td class="center"><?php echo $row['passing_rate'] . "% = (" . ($row['passing_rate'] / 100) * $row['items'] . ")"; ?></td>
                                   <td class="fixedWidth center editButton">
                                        <svg viewBox="0 0 512 512" onclick="showCourseEditModal('<?php echo $row['id']; ?>', '<?php echo $row['description']; ?>', '<?php echo $row['items']; ?>', '<?php echo $row['time_limit']; ?>', '<?php echo $row['passing_rate']; ?>')">
                                            <path d="M490.3 40.4C512.2 62.27 512.2 97.73 490.3 119.6L460.3 149.7L362.3 51.72L392.4 21.66C414.3-.2135 449.7-.2135 471.6 21.66L490.3 40.4zM172.4 241.7L339.7 74.34L437.7 172.3L270.3 339.6C264.2 345.8 256.7 350.4 248.4 353.2L159.6 382.8C150.1 385.6 141.5 383.4 135 376.1C128.6 370.5 126.4 361 129.2 352.4L158.8 263.6C161.6 255.3 166.2 247.8 172.4 241.7V241.7zM192 63.1C209.7 63.1 224 78.33 224 95.1C224 113.7 209.7 127.1 192 127.1H96C78.33 127.1 64 142.3 64 159.1V416C64 433.7 78.33 448 96 448H352C369.7 448 384 433.7 384 416V319.1C384 302.3 398.3 287.1 416 287.1C433.7 287.1 448 302.3 448 319.1V416C448 469 405 512 352 512H96C42.98 512 0 469 0 416V159.1C0 106.1 42.98 63.1 96 63.1H192z"/>
                                        </svg>
                                    </td>
                                </tr>
                                <?php
                            }
                       }
                       else {
                            $sql = "SELECT * FROM subject ORDER BY description ASC";
                            $stmt = mysqli_stmt_init($conn);
                            mysqli_stmt_prepare($stmt, $sql);
                            mysqli_stmt_execute($stmt);
                            $result = mysqli_stmt_get_result($stmt);

                            while ($row = mysqli_fetch_assoc($result)) {
                                ?>
                                <tr>
                                    <td class="left"><?php echo $row['description']; ?></td>
                                    <td class="center"><?php echo $row['items']; ?></td>
                                    <td class="center"><?php echo $row['time_limit'] . " Minutes"; ?></td>
                                    <td class="center"><?php echo $row['passing_rate'] . "% = (" . ($row['passing_rate'] / 100) * $row['items'] . ")"; ?></td>
                                    <td class="fixedWidth center editButton">
                                        <svg viewBox="0 0 512 512" onclick="showCourseEditModal('<?php echo $row['id']; ?>', '<?php echo $row['description']; ?>', '<?php echo $row['items']; ?>', '<?php echo $row['time_limit']; ?>', '<?php echo $row['passing_rate']; ?>')">
                                            <path d="M490.3 40.4C512.2 62.27 512.2 97.73 490.3 119.6L460.3 149.7L362.3 51.72L392.4 21.66C414.3-.2135 449.7-.2135 471.6 21.66L490.3 40.4zM172.4 241.7L339.7 74.34L437.7 172.3L270.3 339.6C264.2 345.8 256.7 350.4 248.4 353.2L159.6 382.8C150.1 385.6 141.5 383.4 135 376.1C128.6 370.5 126.4 361 129.2 352.4L158.8 263.6C161.6 255.3 166.2 247.8 172.4 241.7V241.7zM192 63.1C209.7 63.1 224 78.33 224 95.1C224 113.7 209.7 127.1 192 127.1H96C78.33 127.1 64 142.3 64 159.1V416C64 433.7 78.33 448 96 448H352C369.7 448 384 433.7 384 416V319.1C384 302.3 398.3 287.1 416 287.1C433.7 287.1 448 302.3 448 319.1V416C448 469 405 512 352 512H96C42.98 512 0 469 0 416V159.1C0 106.1 42.98 63.1 96 63.1H192z"/>
                                        </svg>
                                    </td>
                                </tr>
                                <?php
                            }
                       }
                    ?>
                </table>
            </div>
        </div>

        
        <script>
            function showCourseEditModal(id, desc, items, time, rate) {
                editcourse.classList.toggle('visible');
                document.getElementById('editSubjectId').value = id;
                document.getElementById('editSubjectName').value = desc;
                document.getElementById('editSubjectItems').value = items;
                document.getElementById('editSubjectTime').value = time;
                document.getElementById('editSubjectPassing').value = rate;
            }

            function showEditModal(id, fname, lname, add, bdate, token) {
                editmodal.classList.toggle('visible');
                document.getElementById('editId').value = id;
                document.getElementById('editFirstname').value = fname;
                document.getElementById('editLastname').value = lname;
                document.getElementById('editAddress').value = add;
                document.getElementById('editBirthdate').value = bdate;
                document.getElementById('editToken').value = token;
            }

            window.onclick = function(event) {
                if (event.target == editmodal) {
                    editmodal.classList.remove('visible');
                }
                if (event.target == modal) {
                    alert("Please use the close button to close this modal.");
                }
                if (event.target == errormodal) {
                    errormodal.style.display = 'none';
                }
                if (event.target == editmodal) {
                    editmodal.classList.remove('visible');
                }
                if (event.target == coursemodal) {
                    coursemodal.classList.remove('visible');
                }
                if (event.target == editcourse) {
                    editcourse.classList.remove('visible');
                }
            }
        </script>
            

        <script>
        function sortTable(n) {
          var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
          table = document.getElementById("examineeTable");
          switching = true;
          // Set the sorting direction to ascending:
          dir = "asc";
          /* Make a loop that will continue until
          no switching has been done: */
          while (switching) {
            // Start by saying: no switching is done:
            switching = false;
            rows = table.rows;
            /* Loop through all table rows (except the
            first, which contains table headers): */
            for (i = 1; i < (rows.length - 1); i++) {
              // Start by saying there should be no switching:
              shouldSwitch = false;
              /* Get the two elements you want to compare,
              one from current row and one from the next: */
              x = rows[i].getElementsByTagName("TD")[n];
              y = rows[i + 1].getElementsByTagName("TD")[n];
              /* Check if the two rows should switch place,
              based on the direction, asc or desc: */
              if (dir == "asc") {
                if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
                  // If so, mark as a switch and break the loop:
                  shouldSwitch = true;
                  break;
                }
              } else if (dir == "desc") {
                if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
                  // If so, mark as a switch and break the loop:
                  shouldSwitch = true;
                  break;
                }
              }
            }
            if (shouldSwitch) {
              /* If a switch has been marked, make the switch
              and mark that a switch has been done: */
              rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
              switching = true;
              // Each time a switch is done, increase this count by 1:
              switchcount ++;
            } else {
              /* If no switching has been done AND the direction is "asc",
              set the direction to "desc" and run the while loop again. */
              if (switchcount == 0 && dir == "asc") {
                dir = "desc";
                switching = true;
              }
            }
          }
        }
        </script>


    </body>
</html>
