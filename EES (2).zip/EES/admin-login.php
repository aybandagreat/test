<?php session_start(); ?>

<?php
	if (isset($_SESSION['admin']) && !empty($_SESSION['admin'])) {
		header("Location: admin.php");
		exit();
	}
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="admin-login-style.css">
		<title>Entrance Exam | Admin Login</title>
	</head>
	<body>
		<div class="admin-login">
			<div>
				<form method="POST" action="admin-login.sql.php">
					<h4>ADMIN LOGIN</h4>
					<div>
						<label for="username">Username</label>
						<input type="text" name="adminUsername" id="username" required pattern="{0,32}" title="Username must NOT contain more than 32 characters.">
					</div>
					<div>
						<label for="password">Password</label>
						<input type="password" name="adminPassword" id="password" required pattern="{8,}" title="Password must contain atleast 8 characters.">
					</div>
					<?php

						if (isset($_GET['error']) && !empty($_GET['error'])) {
							$err = $_GET['error'];
							?><span id="errmsg"><?php
							if ($err == 'invalid') {
								echo "Admin does not exist!";
							}
							else if ($err == 'invalid') {
								echo "Admin does not exist!";
							}
							?></span><?php
						}

					?>
					<div class="button-container">
						<button type="reset">CLEAR</button>
						<button type="submit" name="adminLogin">LOGIN</button>
					</div>

					<a href="student/student-login.php" style="color: black;">Login as student</a>

				</form>
			</div>
			<div class="title"><h2>ENTRANCE EXAMINATION SYSTEM</h2></div>
			<p class="developer">Contacts</p>
		</div>
	</body>
</html>