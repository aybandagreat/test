<?php
	
	require 'dbconnect.php';

	if (isset($_GET['examinee']) && !empty($_GET['examinee'])) {
		$id = $_GET['examinee'];
    	$sql = "DELETE FROM examinee WHERE id = ?";
        $stmt = mysqli_stmt_init($conn);

    	if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=sqlerror");
            exit();
        }
        else {
            mysqli_stmt_bind_param($stmt, "i", $id);
            mysqli_stmt_execute($stmt);

            header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=deleteSuccess");
	        exit();
	    }
	}

	else if (isset($_GET['question']) && isset($_GET['course']) && !empty($_GET['question']) && !empty($_GET['course'])) {
		$id = $_GET['question'];
    	$sql = "DELETE FROM questions WHERE id = ?";
        $stmt = mysqli_stmt_init($conn);

    	if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=sqlerror");
            exit();
        }
        else {
            mysqli_stmt_bind_param($stmt, "i", $id);
            mysqli_stmt_execute($stmt);

            $sql = "SELECT * FROM narrative_questions WHERE questions_id = ?";
            $stmt = mysqli_stmt_init($conn);

            if (!mysqli_stmt_prepare($stmt, $sql)) {
                header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=sqlerror");
                exit();
            }
            else {
                mysqli_stmt_bind_param($stmt, "i", $id);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_store_result($stmt);
                $rowCount = mysqli_stmt_num_rows($stmt);

                if ($rowCount > 0) {
                    $sql = "DELETE FROM narrative_questions WHERE questions_id = ?";
                    $stmt = mysqli_stmt_init($conn);

                    if (!mysqli_stmt_prepare($stmt, $sql)) {
                        header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=sqlerror");
                        exit();
                    }
                    else {
                        mysqli_stmt_bind_param($stmt, "i", $id);
                        mysqli_stmt_execute($stmt);

                        header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=deleteSuccess&course=" . $_GET['course']);
                        exit();
                    }
                }
                else {
                    header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=deleteSuccess&course=" . $_GET['course']);
                    exit();
                }  
            }
	    }
	}