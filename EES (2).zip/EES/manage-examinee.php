<?php session_start(); ?>

<?php
    if (isset($_SESSION['admin']) && !empty($_SESSION['admin'])) {
        $adminid = $_SESSION['adminid'];
        $admin = $_SESSION['admin'];
        require 'dbconnect.php';
    }
    else if (!isset($_SESSION['admin']) || empty($_SESSION['admin'])) {
        header("Location: admin-login.php?error=invalidaccess");
        exit();
    }
?>


<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="admin-style.css">
        <title>Entrance Exam | Admin</title>
    </head>
    <body>
        <div class="admin-container">
            
            <?php include_once "admin-sidebar.inc.php"; ?>

            <div class="content">
                <div class="search">
                    <h4>Examinee List</h4>
                    <form method="GET">
                        <input type="text" name="searchToken" placeholder="Search Code" >
                        <input type="text" name="searchName" placeholder="Search Name" >
                        <button type="submit">Search</button>
                    </form>
                </div>
                <table class="examinee-table" id="examineeTable">
                    <tr>
                        <th onclick="sortTable(0)">Access Code</th>
                        <th onclick="sortTable(1)">Email</th>
                        <th onclick="sortTable(2)">Examinee Name</th>
                        <th onclick="sortTable(3)">Address</th>
                        <th onclick="sortTable(4)">Birthdate</th>
                        <th onclick="sortTable(5)">Status</th>
                        <th class="fixedWidth"></th>
                        <th class="fixedWidth"></th>
                    </tr>

                    <?php
                        if (isset($_GET['searchToken']) && !empty($_GET['searchToken'])) {
                            $token = $_GET['searchToken'];
                            $sql = "SELECT * FROM examinee WHERE token = '$token' OR token LIKE '%$token%'";
                        }
                        else if (isset($_GET['searchName']) && !empty($_GET['searchName'])) {
                            $name = $_GET['searchName'];
                            $sql = "SELECT * FROM examinee WHERE firstname = '$name' OR lastname = '$name' OR firstname LIKE '%$name%' OR lastname LIKE '%$name%' ORDER BY lastname, firstname ASC";
                        }
                        else {
                            $sql = "SELECT * FROM examinee ORDER BY lastname, firstname ASC";
                        }
                        $stmt = mysqli_stmt_init($conn);
                        mysqli_stmt_prepare($stmt, $sql);
                        mysqli_stmt_execute($stmt);
                        $result = mysqli_stmt_get_result($stmt);

                        while ($row = mysqli_fetch_assoc($result)) {
                            $date = new DateTime($row['birthdate']);
                            $bdate = $date->format("M j, Y");
                            $eid = $row['id'];

                            $sql2 = "SELECT * FROM exam_attempt WHERE examinee_id = '$eid' AND attempt = '1'";
                            mysqli_stmt_prepare($stmt, $sql2);
                            mysqli_stmt_execute($stmt);
                            mysqli_stmt_store_result($stmt);
                            $check2 = mysqli_stmt_num_rows($stmt);

                            if ($check2 == 0) {
                                $status = "<td class='center' style='color: red;'>Not yet answered</td>";
                            }
                            else if ($check2 > 0) {
                                $sql2 = "SELECT * FROM exam_attempt WHERE examinee_id = '$eid' AND attempt = '0'";
                                mysqli_stmt_prepare($stmt, $sql2);
                                mysqli_stmt_execute($stmt);
                                mysqli_stmt_store_result($stmt);
                                $check2 = mysqli_stmt_num_rows($stmt);
                                if ($check2 == 0) {
                                    $status = "<td class='center' style='color: green;'>Answered</td>";
                                }
                                else if ($check2 > 0) {
                                    $status = "<td class='center' style='color: orange;'>Answering</td>";
                                }
                            }
                            else {
                                $status = "<td class='center' style='color: black;'>TBA</td>";
                            }

                            ?>

                            <tr class="viewExmainee" onclick="viewExaminee(<?php echo $eid; ?>)">
                                <td class="center"><?php echo $row['token']; ?></td>
                                <td class="left lowercase"><?php echo $row['email']; ?></td>
                                <td class="left" style="text-transform: uppercase;"><?php echo $row['lastname'] . ", " . $row['firstname']; ?></td>
                                <td class="left"><?php echo $row['address']; ?></td>    
                                <td class="left"><?php echo $bdate; ?></td>
                                <?php echo $status; ?>

                                <td class="fixedWidth center editButton">
                                    <svg viewBox="0 0 512 512" onclick="showEditModal('<?php echo $row['id']; ?>', '<?php echo $row['firstname']; ?>', '<?php echo $row['lastname']; ?>', '<?php echo $row['address']; ?>', '<?php echo $row['birthdate']; ?>', '<?php echo $row['token']; ?>', event)">
                                        <path d="M490.3 40.4C512.2 62.27 512.2 97.73 490.3 119.6L460.3 149.7L362.3 51.72L392.4 21.66C414.3-.2135 449.7-.2135 471.6 21.66L490.3 40.4zM172.4 241.7L339.7 74.34L437.7 172.3L270.3 339.6C264.2 345.8 256.7 350.4 248.4 353.2L159.6 382.8C150.1 385.6 141.5 383.4 135 376.1C128.6 370.5 126.4 361 129.2 352.4L158.8 263.6C161.6 255.3 166.2 247.8 172.4 241.7V241.7zM192 63.1C209.7 63.1 224 78.33 224 95.1C224 113.7 209.7 127.1 192 127.1H96C78.33 127.1 64 142.3 64 159.1V416C64 433.7 78.33 448 96 448H352C369.7 448 384 433.7 384 416V319.1C384 302.3 398.3 287.1 416 287.1C433.7 287.1 448 302.3 448 319.1V416C448 469 405 512 352 512H96C42.98 512 0 469 0 416V159.1C0 106.1 42.98 63.1 96 63.1H192z"/>
                                    </svg>
                                </td>

                                <td class="fixedWidth deleteButton center">
                                    <svg viewBox="0 0 448 512" onclick="deleteButton(<?php echo $row['id']; ?>, event)">
                                        <path d="M135.2 17.69C140.6 6.848 151.7 0 163.8 0H284.2C296.3 0 307.4 6.848 312.8 17.69L320 32H416C433.7 32 448 46.33 448 64C448 81.67 433.7 96 416 96H32C14.33 96 0 81.67 0 64C0 46.33 14.33 32 32 32H128L135.2 17.69zM31.1 128H416V448C416 483.3 387.3 512 352 512H95.1C60.65 512 31.1 483.3 31.1 448V128zM111.1 208V432C111.1 440.8 119.2 448 127.1 448C136.8 448 143.1 440.8 143.1 432V208C143.1 199.2 136.8 192 127.1 192C119.2 192 111.1 199.2 111.1 208zM207.1 208V432C207.1 440.8 215.2 448 223.1 448C232.8 448 240 440.8 240 432V208C240 199.2 232.8 192 223.1 192C215.2 192 207.1 199.2 207.1 208zM304 208V432C304 440.8 311.2 448 320 448C328.8 448 336 440.8 336 432V208C336 199.2 328.8 192 320 192C311.2 192 304 199.2 304 208z"/>
                                    </svg>
                                </td>
                            </tr>
                            <?php
                        }
                    ?>
                </table>
            </div>
        </div>

        
        <script>
            function deleteButton(id, e) {
                e.stopPropagation();
                var confirmDel = confirm('Please confirm delete');
                if (confirmDel == false) {
                    return false;
                }
                else if (confirmDel == true) {
                    location.href = "delete-functions.php?examinee=" + id;
                }
            }

            function showEditModal(id, fname, lname, add, bdate, token, e) {
                e.stopPropagation();
                editmodal.classList.toggle('visible');
                document.getElementById('editId').value = id;
                document.getElementById('editFirstname').value = fname;
                document.getElementById('editLastname').value = lname;
                document.getElementById('editAddress').value = add;
                document.getElementById('editBirthdate').value = bdate;
                document.getElementById('editToken').value = token;
            }

            function viewExaminee(examineeid) {
                location.href = 'view-examinee.php?examinee=' + examineeid;
            }

            window.onclick = function(event) {
                if (event.target == editmodal) {
                    editmodal.classList.remove('visible');
                }
                if (event.target == modal) {
                    alert("Please use the close button to close this modal.");
                }
                if (event.target == errormodal) {
                    errormodal.style.display = 'none';
                }
                if (event.target == editmodal) {
                    editmodal.classList.remove('visible');
                }
                if (event.target == coursemodal) {
                    coursemodal.classList.remove('visible');
                }
            }
        </script>
            

        <script>
        function sortTable(n) {
          var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
          table = document.getElementById("examineeTable");
          switching = true;
          // Set the sorting direction to ascending:
          dir = "asc";
          /* Make a loop that will continue until
          no switching has been done: */
          while (switching) {
            // Start by saying: no switching is done:
            switching = false;
            rows = table.rows;
            /* Loop through all table rows (except the
            first, which contains table headers): */
            for (i = 1; i < (rows.length - 1); i++) {
              // Start by saying there should be no switching:
              shouldSwitch = false;
              /* Get the two elements you want to compare,
              one from current row and one from the next: */
              x = rows[i].getElementsByTagName("TD")[n];
              y = rows[i + 1].getElementsByTagName("TD")[n];
              /* Check if the two rows should switch place,
              based on the direction, asc or desc: */
              if (dir == "asc") {
                if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
                  // If so, mark as a switch and break the loop:
                  shouldSwitch = true;
                  break;
                }
              } else if (dir == "desc") {
                if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
                  // If so, mark as a switch and break the loop:
                  shouldSwitch = true;
                  break;
                }
              }
            }
            if (shouldSwitch) {
              /* If a switch has been marked, make the switch
              and mark that a switch has been done: */
              rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
              switching = true;
              // Each time a switch is done, increase this count by 1:
              switchcount ++;
            } else {
              /* If no switching has been done AND the direction is "asc",
              set the direction to "desc" and run the while loop again. */
              if (switchcount == 0 && dir == "asc") {
                dir = "desc";
                switching = true;
              }
            }
          }
        }
        </script>

    </body>
</html>

