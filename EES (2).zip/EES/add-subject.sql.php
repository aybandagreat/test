<?php
    if (isset($_POST['add-subject-button'])) {
        
        if (empty($_POST['subjectName']) || empty($_POST['subjectItems']) || empty($_POST['subjectTime']) || empty($_POST['subjectPassing'])) {
            header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=emptyinputs");
            exit();
        }
        else if (!empty($_POST['subjectName']) && !empty($_POST['subjectItems']) && !empty($_POST['subjectTime']) && !empty($_POST['subjectPassing'])) {

            require 'dbconnect.php';

            $description = trim($_POST['subjectName']);
            $items = trim($_POST['subjectItems']);
            $times = trim($_POST['subjectTime']);
            $passing = trim($_POST['subjectPassing']);

            
            $sql = "SELECT * FROM subject WHERE description = ?";
            $stmt = mysqli_stmt_init($conn);

            if (!mysqli_stmt_prepare($stmt, $sql)) {
                 header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=sqlerror");
                exit();
            }
            else {
                mysqli_stmt_bind_param($stmt, "s", $description);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_store_result($stmt);

                $resultcheck = mysqli_stmt_num_rows($stmt);

                if ($resultcheck > 0) {
                    header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=courseexists");
                    exit();
                }
                else {

                    $sql = "INSERT INTO subject (description, items, time_limit, passing_rate) VALUES (?, ?, ?, ?)";
                    $stmt = mysqli_stmt_init($conn);

                    if (!mysqli_stmt_prepare($stmt, $sql)) {
                        header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=sqlerror");
                        exit();
                    }
                    else {

                        mysqli_stmt_bind_param($stmt, "siii", $description, $items, $times, $passing);
                        mysqli_stmt_execute($stmt);
                        $subjectid = mysqli_stmt_insert_id($stmt);
                        $attempt = 0;

                        $sql = "SELECT id FROM examinee";
                        $stmt = mysqli_stmt_init($conn);
                        mysqli_stmt_prepare($stmt, $sql);
                        mysqli_stmt_execute($stmt);
                        $result = mysqli_stmt_get_result($stmt);

                        while ($row = mysqli_fetch_assoc($result)) {
                            $examineeid = $row['id'];
                            $sql2 = "INSERT INTO exam_attempt (subject_id, examinee_id, attempt) VALUES (?, ?, ?)";
                            $stmt2 = mysqli_stmt_init($conn);
                            mysqli_stmt_prepare($stmt2, $sql2);
                            mysqli_stmt_bind_param($stmt2, "iii", $subjectid, $examineeid, $attempt);
                            mysqli_stmt_execute($stmt2);
                        }


                        header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?msg=addcoursesuccess&description=" . $description . "&items=" . $items . "&time=" . $times . "&passing=" . $passing);
                        exit();
                    }
                }
            }
        }
    }
    else if (!isset($_POST['add-subject-button'])) {
         header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=invalidaccess");
        exit();
    }
    else {
        header("Location: " . $_SERVER['HTTP_REFERER']);
        exit();
    }