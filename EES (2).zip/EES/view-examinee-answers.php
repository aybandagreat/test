<?php session_start(); ?>

<?php
    if (isset($_SESSION['admin']) && !empty($_SESSION['admin'])) {
        $adminid = $_SESSION['adminid'];
        $admin = $_SESSION['admin'];
        require 'dbconnect.php';
    }
    else if (!isset($_SESSION['admin']) || empty($_SESSION['admin'])) {
        header("Location: admin-login.php?error=invalidaccess");
        exit();
    }
?>


<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="admin-style.css">
        <title>Entrance Exam | Admin</title>
    </head>
    <body>
        <div class="admin-container">
            
            <?php include_once "admin-sidebar.inc.php"; ?>

            <div class="content">
                <div class="search">
                    <?php
                        if (!isset($_GET['examinee']) || empty($_GET['examinee'])) {
                            header("Location: manage-examinee.php");
                            exit();
                        }
                        else {
                            $eid = $_GET['examinee'];
                            $sid = $_GET['subject'];
                        }

                        $sql = "SELECT * FROM subject WHERE id = $sid";
                        $stmt = mysqli_stmt_init($conn);
                        mysqli_stmt_prepare($stmt, $sql);
                        mysqli_stmt_execute($stmt);
                        $result = mysqli_stmt_get_result($stmt);

                        if ($row = mysqli_fetch_assoc($result)) {
                            $subjectName = $row['description'];
                        }

                        $sql = "SELECT * FROM examinee WHERE id = $eid";
                        $stmt = mysqli_stmt_init($conn);
                        mysqli_stmt_prepare($stmt, $sql);
                        mysqli_stmt_execute($stmt);
                        $result = mysqli_stmt_get_result($stmt);

                        if ($row = mysqli_fetch_assoc($result)) {
                            $name = $row['lastname'] . ", " . $row['firstname'];
                            ?>
                                <h3 style="margin: 0;"><?php echo $row['token'] . " - " . strtoupper($name) . " | " . $subjectName; ?></h3>
                            <?php
                        }
                    ?>
                </div>
                <table class="examinee-table" id="examineeTable" style="border: none;">
                    <tr>
                        <th>#</th>
                        <th>Question</th>
                        <th>Answer</th>
                        <th>Correct Answer</th>
                    </tr>

                    <?php
                        $totalscore = 0;
                        $totalitems = 0;
                        $sql = "
                        SELECT questions.*, exam_answers.answer AS examineeAnswer 
                        FROM questions 

                        LEFT JOIN exam_answers ON questions.id = exam_answers.question_id 

                        WHERE questions.subject_id = $sid 

                        AND questions.id IN (SELECT question_id FROM exam_answers WHERE examinee_id = $eid) 

                        AND exam_answers.examinee_id = $eid GROUP BY exam_answers.id";
                        $stmt = mysqli_stmt_init($conn);
                        mysqli_stmt_prepare($stmt, $sql);
                        mysqli_stmt_execute($stmt);
                        $result = mysqli_stmt_get_result($stmt);

                        $counter = 0;

                        while ($row = mysqli_fetch_assoc($result)) {
                            $counter++;

                            if ($row['answer'] == $row['examineeAnswer']) {
                                ?>
                                    <tr class="correctAnswer">
                                        <td class="center"><?php echo $counter; ?></td>
                                        <td class="left"><?php echo $row['question']; ?></td>
                                        <td class="left"><?php echo $row['examineeAnswer']; ?></td>
                                        <td class="left"><?php echo $row['answer']; ?></td>
                                    </tr>
                                <?php
                            }
                            else {
                                ?>
                                    <tr class="incorrectAnswer">
                                        <td class="center"><?php echo $counter; ?></td>
                                        <td class="left"><?php echo $row['question']; ?></td>
                                        <td class="left"><?php echo $row['examineeAnswer']; ?></td>
                                        <td class="left"><?php echo $row['answer']; ?></td>
                                    </tr>
                                <?php
                            }

                        }
                        if ($totalscore != 0) {
                            $totalpercent = $totalscore / $totalitems * 100;
                        }
                        else {
                            $totalpercent = 0;
                        }

                    ?>
                    <tr style="background-color: transparent; font-weight: bold;">
                        <td class="left" style="border: none;">TOTAL</td>
                        <td class="center" style="border: none;"><?php echo $totalscore; ?></td>
                        <td class="center" style="border: none;"><?php echo $totalitems; ?></td>
                        <td class="center" style="border: none;"><?php echo round($totalpercent,1) . "%"; ?></td>
                    </tr>
                    
                </table>
            </div>
        </div>

        
        <script>

            function showEditModal(id, fname, lname, add, bdate, token) {
                editmodal.classList.toggle('visible');
                document.getElementById('editId').value = id;
                document.getElementById('editFirstname').value = fname;
                document.getElementById('editLastname').value = lname;
                document.getElementById('editAddress').value = add;
                document.getElementById('editBirthdate').value = bdate;
                document.getElementById('editToken').value = token;
            }

            window.onclick = function(event) {
                if (event.target == editmodal) {
                    editmodal.classList.remove('visible');
                }
                if (event.target == modal) {
                    alert("Please use the close button to close this modal.");
                }
                if (event.target == errormodal) {
                    errormodal.style.display = 'none';
                }
                if (event.target == editmodal) {
                    editmodal.classList.remove('visible');
                }
                if (event.target == coursemodal) {
                    coursemodal.classList.remove('visible');
                }
            }
        </script>

    </body>
</html>

