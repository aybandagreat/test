<?php session_start(); ?>

<?php
    if (isset($_SESSION['admin']) && !empty($_SESSION['admin'])) {
        $adminid = $_SESSION['adminid'];
        $admin = $_SESSION['admin'];
        require 'dbconnect.php';
    }
    else if (!isset($_SESSION['admin']) || empty($_SESSION['admin'])) {
        header("Location: admin-login.php?error=invalidaccess");
        exit();
    }
?>


<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="admin-style.css">
        <title>Entrance Exam | Admin</title>
        <script src="jquery-3.6.0.js"></script>
    </head>
    <body>
        <div class="admin-container">
            
            <?php include_once "admin-sidebar.inc.php"; ?>

            <div class="content">
                <div class="search">
                    <h4>Exam Questions</h4>
                   <div>
                        <label>View questions of:</label>
                        <select onchange="changeUrl(this.value)">
                            <?php

                                if (isset($_GET['course']) && !empty($_GET['course'])) {
                                    $id=$_GET['course'];
                                }
                                else {
                                    $sql = "SELECT * FROM subject ORDER BY id ASC LIMIT 1";
                                    $stmt = mysqli_stmt_init($conn);
                                    mysqli_stmt_prepare($stmt, $sql);
                                    mysqli_stmt_execute($stmt);
                                    $result = mysqli_stmt_get_result($stmt);

                                    if ($row = mysqli_fetch_assoc($result)) {
                                        $id = $row['id'];
                                    }
                                }

                                $sql = "SELECT * FROM subject";
                                $stmt = mysqli_stmt_init($conn);
                                mysqli_stmt_prepare($stmt, $sql);
                                mysqli_stmt_execute($stmt);
                                $result = mysqli_stmt_get_result($stmt);

                                while ($row = mysqli_fetch_assoc($result)) {
                                    if (isset($id) && !empty($id) && $id == $row['id']) {
                                        ?><option value="<?php echo $row['id']; ?>" selected><?php echo $row['description']; ?></option><?php
                                    }
                                    else {
                                        ?><option value="<?php echo $row['id']; ?>"><?php echo $row['description']; ?></option><?php
                                    }
                                }
                            ?>
                        </select>
                   </div>
                </div>
                <div class="exam-form">
                    <form method="POST" action="add-question.sql.php">

                        <?php

                            $sql = "SELECT * FROM narrative WHERE subject_id = $id";
                            $stmt = mysqli_stmt_init($conn);
                            mysqli_stmt_prepare($stmt, $sql);
                            mysqli_stmt_execute($stmt);
                            $result = mysqli_stmt_get_result($stmt);

                            $num = 0;
                            $num2 = 0;
                            while ($row = mysqli_fetch_assoc($result)) {
                                $num2++;
                                ?>
                                    <div class="items">
                                        <div>
                                            <h4>Narrative Question <?php echo $num2; ?></h4>
                                        </div>
                                        <div>
                                            <p><?php echo $row['narrative']; ?></p>
                                        </div>
                                        <button type="button" onclick="editNarrative(<?php echo $row['id']; ?>, <?php echo $id; ?>)">Edit</button>
                                <?php
                                $nid = $row['id'];
                                $sql2 = "SELECT * FROM questions WHERE id IN (SELECT questions_id FROM narrative_questions WHERE narrative_id IN (SELECT id FROM narrative WHERE id = $nid))";
                                $stmt2 = mysqli_stmt_init($conn);
                                mysqli_stmt_prepare($stmt2, $sql2);
                                mysqli_stmt_execute($stmt2);
                                $result2 = mysqli_stmt_get_result($stmt2);

                                $num = 0;
                                while ($row2 = mysqli_fetch_assoc($result2)) {
                                    $num++;
                                    $question=$row2['question'];
                                    $choice1=$row2['choice1'];
                                    $choice2=$row2['choice2'];
                                    $choice3=$row2['choice3'];
                                    $choice4=$row2['choice4'];
                                    $answer=$row2['answer'];
                                    ?>
                                            <div style="padding-left: 1em;">
                                                <h4><?php echo $num . ". " . $question; ?></h4>
                                            </div>
                                            <div style="padding-left: 1em;">
                                                <p class="choices">A. <?php echo $choice1; ?></p>
                                                <p class="choices">B. <?php echo $choice2; ?></p>
                                                <p class="choices">C. <?php echo $choice3; ?></p>
                                                <p class="choices">D. <?php echo $choice4; ?></p>
                                            </div>
                                            <div style="padding-left: 1em;">
                                                <p>Answer: <?php echo $answer; ?></p>
                                            </div>
                                            <div class="edit-button-container" style="margin-left: 2rem;">
                                                <button type="button" onclick="editQuestion(<?php echo $row2['id']; ?>, <?php echo $id; ?>)">Edit</button>
                                                <button type="button" onclick="deleteButton(<?php echo $row2['id']; ?>, <?php echo $id; ?>, event)">Del</button>
                                            </div>
                                    <?php
                                }
                                ?>
                                </div>
                                <?php
                            }

                            $sql = "SELECT * FROM questions WHERE subject_id = $id AND id NOT IN (SELECT questions_id FROM narrative_questions)";
                            $stmt = mysqli_stmt_init($conn);
                            mysqli_stmt_prepare($stmt, $sql);
                            mysqli_stmt_execute($stmt);
                            $result = mysqli_stmt_get_result($stmt);

                            $num = 0;

                            while ($row = mysqli_fetch_assoc($result)) {
                                $num++;
                                $question=$row['question'];
                                $choice1=$row['choice1'];
                                $choice2=$row['choice2'];
                                $choice3=$row['choice3'];
                                $choice4=$row['choice4'];
                                $answer=$row['answer'];
                                ?>
                                    <div class="items">
                                        <div>
                                            <h4><?php echo $num . ". " . $question; ?></h4>
                                        </div>
                                        <div>
                                            <p class="choices">A. <?php echo $choice1; ?></p>
                                            <p class="choices">B. <?php echo $choice2; ?></p>
                                            <p class="choices">C. <?php echo $choice3; ?></p>
                                            <p class="choices">D. <?php echo $choice4; ?></p>
                                        </div>
                                        <div>
                                            <p>Answer: <?php echo $answer; ?></p>
                                        </div>
                                        <div class="edit-button-container" style="margin-left: 2rem;">
                                                <button type="button" onclick="editQuestion(<?php echo $row2['id']; ?>, <?php echo $id; ?>)">Edit</button>
                                                <button type="button" onclick="deleteButton(<?php echo $row2['id']; ?>, <?php echo $id; ?>, event)">Del</button>
                                            </div>
                                    </div>
                                <?php
                            }

                            if ($num == 0) {

                                $sql = "SELECT * FROM subject";
                                $stmt = mysqli_stmt_init($conn);
                                mysqli_stmt_prepare($stmt, $sql);
                                mysqli_stmt_execute($stmt);
                                mysqli_stmt_store_result($stmt);
                                $numrows = mysqli_stmt_num_rows($stmt);
                                if ($numrows > 0) {

                                    $sql2 = "SELECT * FROM questions WHERE subject_id = $id";
                                    $stmt2 = mysqli_stmt_init($conn);
                                    mysqli_stmt_prepare($stmt2, $sql2);
                                    mysqli_stmt_execute($stmt2);
                                    mysqli_stmt_store_result($stmt2);
                                    $numrows2 = mysqli_stmt_num_rows($stmt2);
                                    if ($numrows2 == 0) {
                                        ?>
                                            <h4>You haven't added questions for this subject yet. <a href="add-question.php?course=<?php echo $id; ?>">Click here</a> to add questions.</h2>
                                        <?php
                                    }
                                    
                                }
                                else if ($numrows == 0) {
                                    ?>
                                        <h4>You haven't added any subject yet. <a onclick="showCourseModal()" style="cursor: pointer; text-decoration: underline;">Click here</a> to add a subject.</h2>
                                    <?php
                                }
                                
                            }
                        ?>
                        <?php
                            /*if (isset($_GET['course'])) {
                                $sql = "SELECT * FROM subject WHERE id=$id";
                                $stmt = mysqli_stmt_init($conn);
                                mysqli_stmt_prepare($stmt, $sql);
                                mysqli_stmt_execute($stmt);
                                mysqli_stmt_store_result($stmt);

                                $resultcheck = mysqli_stmt_num_rows($stmt);

                                ?>
                                    <div class="course">
                                        <span>Total added questions: <?php echo $resultcheck; ?></span>
                                        <span>Course: <?php echo $course; ?></span>
                                        <span>Items: <?php echo $items; ?></span>
                                        <span>Allocated: <?php echo $time; ?> minutes</span>
                                    </div>
                                <?php
                            }*/
                        ?>

                        
                    </form>
                </div>
            </div>
        </div>
        <div class="token-modal" id="narrativeModal">
        </div>
        <script>
            function deleteButton(id, course, e) {
                e.stopPropagation();
                var confirmDel = confirm('Please confirm delete');
                if (confirmDel == false) {
                    return false;
                }
                else if (confirmDel == true) {
                    location.href = "delete-functions.php?question=" + id + "&course=" + course;
                }
            }

            let narrativemodal = document.getElementById('narrativeModal');

            function changeUrl(id) {
                location.href = 'questions.php?course=' + id;
            }

            function showCourseEditModal(id, desc, items, time, rate) {
                editcourse.classList.toggle('visible');
                document.getElementById('editCourseId').value = id;
                document.getElementById('editCourseName').value = desc;
                document.getElementById('editCourseItems').value = items;
                document.getElementById('editCourseTime').value = time;
                document.getElementById('editCoursePassing').value = rate;
            }

            function showEditModal(id, fname, lname, add, bdate, token) {
                editmodal.classList.toggle('visible');
                document.getElementById('editId').value = id;
                document.getElementById('editFirstname').value = fname;
                document.getElementById('editLastname').value = lname;
                document.getElementById('editAddress').value = add;
                document.getElementById('editBirthdate').value = bdate;
                document.getElementById('editToken').value = token;
            }

            function editQuestion(id, subjId) {
                narrativemodal.classList.toggle('visible');
                $(narrativemodal).load("question-modal.php", {question: id, subject: subjId});
            }

            function editNarrative(id, subjId) {
                narrativemodal.classList.toggle('visible');
                $(narrativemodal).load("narrative-modal.php", {narrative: id, subject: subjId});
            }

            window.onclick = function(event) {
                if (event.target == editmodal) {
                    editmodal.classList.remove('visible');
                }
                if (event.target == modal) {
                    alert("Please use the close button to close this modal.");
                }
                if (event.target == errormodal) {
                    errormodal.style.display = 'none';
                }
                if (event.target == editmodal) {
                    editmodal.classList.remove('visible');
                }
                if (event.target == coursemodal) {
                    coursemodal.classList.remove('visible');
                }
                if (event.target == editcourse) {
                    editcourse.classList.remove('visible');
                }
                if (event.target == narrativemodal) {
                    narrativemodal.classList.remove('visible');
                }
            }

            function closeModal() {
                modal.classList.remove('visible');
                editmodal.classList.remove('visible');
                coursemodal.classList.remove('visible');
                editcourse.classList.remove('visible');
                narrativemodal.classList.remove('visible');
            }
        </script>
    </body>
</html>

