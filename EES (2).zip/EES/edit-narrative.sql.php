<?php

    if (!isset($_POST['narrative-button'])) {
        header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=unauthorized");
        exit();
    }
    else if (isset($_POST['narrative-button'])) {
        
        if (empty($_POST['editNarrative']) || empty($_POST['narrativeQuestionId'])) {
            header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=emptyinputs");
            exit();
        }
        else if (!empty($_POST['editNarrative']) && !empty($_POST['narrativeQuestionId'])) {

            require 'dbconnect.php';

            $nid = $_POST['narrativeQuestionId'];
            $narrative = $_POST['editNarrative'];
            $sid = $_POST['subjectId'];
            
            $sql = "SELECT * FROM narrative WHERE id = ?";
            $stmt = mysqli_stmt_init($conn);

            if (!mysqli_stmt_prepare($stmt, $sql)) {
                header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=sqlerror");
                exit();
            }
            else {
                mysqli_stmt_bind_param($stmt, "i", $nid);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_store_result($stmt);

                $resultcheck = mysqli_stmt_num_rows($stmt);

                if ($resultcheck == 0) {
                    header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=narrativedoesnotexist");
                    exit();
                }
                else {

                    $sql = "SELECT * FROM narrative WHERE id = ? AND narrative = ?";
                    $stmt = mysqli_stmt_init($conn);

                    if (!mysqli_stmt_prepare($stmt, $sql)) {
                        header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=sqlerror");
                        exit();
                    }
                    else {
                        mysqli_stmt_bind_param($stmt, "is", $nid, $narrative);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_store_result($stmt);

                        $resultcheck = mysqli_stmt_num_rows($stmt);

                        if ($resultcheck == 1) {
                            header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=nochangesfound");
                            exit();
                        }
                        else {
                            $sql = "UPDATE narrative SET narrative = ? WHERE id = ?";
                            $stmt = mysqli_stmt_init($conn);

                            if (!mysqli_stmt_prepare($stmt, $sql)) {
                                header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=sqlerror");
                                exit();
                            }
                            else {

                                mysqli_stmt_bind_param($stmt, "si", $narrative, $nid);
                                mysqli_stmt_execute($stmt);

                                header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?msg=editnarrativesuccess&course=".$sid);
                                exit();
                            }
                        }
                    }
                }
            }
        }
    }