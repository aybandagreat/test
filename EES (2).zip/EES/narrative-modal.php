<?php

    require 'dbconnect.php';

    if (isset($_POST['narrative']) && !empty($_POST['narrative'])) {
        $id = $_POST['narrative'];
        $sql = "SELECT * FROM narrative WHERE id = $id";
        $stmt = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($stmt, $sql);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        while ($row = mysqli_fetch_assoc($result)) {
            ?>
            <div>
                <form action="edit-narrative.sql.php" method="POST">
                    <h4>EDIT NARRATIVE QUESTION</h4>
                    <div style="flex-direction: column; height: 100%;">
                        <label for="editQuestion">Narrative Question</label>
                        <textarea name="editNarrative" required id="editNarrativeInput"><?php echo $row['narrative']; ?></textarea>
                    </div>
                    <input type='hidden' name='narrativeQuestionId' value="<?php echo $row['id']; ?>">
                    <input type='hidden' name='subjectId' value="<?php echo $_POST['subject']; ?>">
                    <div class="button-container">
                        <button type="button" onclick="closeModal()">CANCEL</button>
                        <button type="submit" name="narrative-button">EDIT</button>
                    </div>
                </form>
            </div>
            <?php
        }
    }

    
    
?>