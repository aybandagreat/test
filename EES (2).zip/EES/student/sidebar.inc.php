<div class="sidemenu">
    <div class="items-container">
        <?php
            require '../dbconnect.php';
            $sql = "SELECT subject.id, subject.description, exam_attempt.attempt 
            FROM subject 
            INNER JOIN exam_attempt ON subject.id = exam_attempt.subject_id 
            WHERE exam_attempt.examinee_id = '$eid' ORDER BY description ASC";
            $stmt = mysqli_stmt_init($conn);
            mysqli_stmt_prepare($stmt, $sql);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            while ($row = mysqli_fetch_assoc($result)) {
                if ($row['attempt'] == 0) {
                    ?>
                    <div class="items" onclick="confirmAttempt('<?php echo $row['id']; ?>')"><?php echo $row['description']; ?></div>
                    <?php
                }
                else if ($row['attempt'] == 1) {
                    ?>
                    <div class="items subjectdone" title="You have finished answering this subject."><a href="?subject=<?php echo $row['id']; ?>"><?php echo $row['description']; ?></a></div>
                    <?php
                }
            }

        ?>
    </div>

    <div class="token-modal" id="confirmattempt">
        <div>
            <form action="startanswer.sql.php" method="post">
                <input type="hidden" name="subjectid" value="" id="subjectID">
                <input type="hidden" name="examineeid" value="<?php echo $eid; ?>">
                <h4 class="note" style="align-self: flex-start;">Please take note of the following:</h4>

                <p style="align-self: flex-start; margin:0;">- You can only take this exam once.</p>
                <p style="align-self: flex-start; margin:0;">- This examination has time limit.</p>

                <h4 style="align-self: flex-start;">Do you want to start? </h4>
                <div class="button-container">
                    <button type="button" onclick="closeModal()">CANCEL</button>
                    <button type="submit" name="startbutton">START</button>
                </div>
            </form>
        </div>
    </div>

    <div class="logout-container">
        <div class="items _logout"><a href="logout.sql.php">Logout</a></div>
    </div>
</div>





<?php
    if (isset($_GET['error']) && !empty($_GET['error'])) {
        $err = $_GET['error'];
        $text;
        if ($err == "noquestionsyet") {
            $text = "No questions for this subject yet.<br>Please try again later.";
        }
        ?>
            <div class="error-modal" id="errormodal">
                <div>
                    <h4><?php echo $text; ?></h4>
                    <div class="button-container">
                        <button type="button" onclick="closeModal()" style="align-self: flex-end;">OK</button>
                    </div>
                </div>
            </div>
        <?php
    }
?>




<script>
    function confirmAttempt(subject) {
        document.getElementById('confirmattempt').classList.toggle('visible');
        document.getElementById('subjectID').value = subject;
    }
    error = document.getElementById('errormodal');
    function closeModal() {
        modal = document.querySelector('#confirmattempt');
        modal.classList.remove('visible');
        error.style.display = "none";
    }
    window.onclick = function(event) {
        if (event.target == error) {
            error.style.display = "none";
        }
    }
</script>