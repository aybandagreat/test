<?php
	header("Location: student-login.php");
	exit();
?>