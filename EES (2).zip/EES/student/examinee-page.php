<?php
	if (session_status() == PHP_SESSION_NONE) {
		session_start();
	}

	if (!isset($_SESSION['examineeid']) || empty($_SESSION['examineeid'])) {
		header("Location: student-login.php");
		exit();
	}
	else if (isset($_SESSION['examineeid']) && !empty($_SESSION['examineeid'])) {
		$eid = $_SESSION['examineeid'];

		require '../dbconnect.php';

		$sql = "SELECT * FROM examinee WHERE id = '$eid'";
        $stmt = mysqli_stmt_init($conn);
        mysqli_stmt_prepare($stmt, $sql);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($row = mysqli_fetch_assoc($result)) {
        	$elast = $row['lastname'];
        	$efirst = $row['firstname'];
        }
	}
?>


<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Entrance Exam | Student</title>
		<link rel="stylesheet" type="text/css" href="student-style.css">
	</head>
	<body class="admin-container">
		<?php include_once "sidebar.inc.php"; ?>


		<div class="content">
			
			<?php
				if (isset($_SESSION['subject']) && !empty($_SESSION['subject'])) {
					$sid = $_SESSION['subject'];
					?>
						<div class="exam-form">
							<form action="examineeanswer.sql.php" method="post" id="questionform">
								<p class="timer" id="counter"></p>
								<?php
									$sql = "SELECT description, items, time_limit FROM subject WHERE id = '$sid'";
								    $stmt = mysqli_stmt_init($conn);
								    mysqli_stmt_prepare($stmt, $sql);
								    mysqli_stmt_execute($stmt);
								    $result = mysqli_stmt_get_result($stmt);

								    if ($row = mysqli_fetch_assoc($result)) {
								    	$limit = intval($row['items']);
								    	$time = intval($row['time_limit']);
								    	?><div class="subjectname"><h3><?php echo $row['description']; ?></h3></div><?php
								    }

								    $sql = "SELECT * FROM narrative WHERE subject_id = $sid ORDER BY RAND()";
		                            $stmt = mysqli_stmt_init($conn);
		                            mysqli_stmt_prepare($stmt, $sql);
		                            mysqli_stmt_execute($stmt);
		                            $result = mysqli_stmt_get_result($stmt);

		                            $num = 0;
		                            $num2 = 0;
		                            while ($row = mysqli_fetch_assoc($result)) {
		                                $num2++;
		                                ?>
		                                    <div class="items">
		                                        <div>
		                                            <h4>Narrative Question <?php echo $num2; ?></h4>
		                                        </div>
		                                        <div style="">
		                                            <p><?php echo $row['narrative']; ?></p>
		                                        </div>
		                                        <hr style="border-top: 1px solid black; width: 100%;">
		                                <?php
		                                $nid = $row['id'];
		                                $sql2 = "SELECT id, question, choice1, choice2, choice3, choice4 FROM questions WHERE id IN (SELECT questions_id FROM narrative_questions WHERE narrative_id IN (SELECT id FROM narrative WHERE id = $nid))";
		                                $stmt2 = mysqli_stmt_init($conn);
		                                mysqli_stmt_prepare($stmt2, $sql2);
		                                mysqli_stmt_execute($stmt2);
		                                $result2 = mysqli_stmt_get_result($stmt2);

		                                $num = 0;
		                                while ($row2 = mysqli_fetch_assoc($result2)) {
		                                    $num++;
		                                    $limit--;
		                                    $question=$row2['question'];
		                                    $choice1=$row2['choice1'];
		                                    $choice2=$row2['choice2'];
		                                    $choice3=$row2['choice3'];
		                                    $choice4=$row2['choice4'];
		                                    ?>
	                                            <div style="padding-left: 1em;">
	                                                <h4><?php echo $num . ". " . $question; ?></h4>
	                                            </div>
	                                            <div class="choicecontainer">
		                                            <div>
		                                            	<input type="radio" name="<?php echo $row2['id']; ?>" value="<?php echo $choice1; ?>">
		                                            	<label><?php echo $choice1; ?></label>
		                                            </div>
		                                            <div>
		                                            	<input type="radio" name="<?php echo $row2['id']; ?>" value="<?php echo $choice2; ?>">
		                                            	<label><?php echo $choice2; ?></label>
		                                            </div>
		                                            <div>
		                                            	<input type="radio" name="<?php echo $row2['id']; ?>" value="<?php echo $choice3; ?>">
		                                            	<label><?php echo $choice3; ?></label>
		                                            </div>
		                                            <div>
		                                            	<input type="radio" name="<?php echo $row2['id']; ?>" value="<?php echo $choice4; ?>">
		                                            	<label><?php echo $choice4; ?></label>
		                                            </div>
		                                        </div>
		                                    <?php
		                                }
		                                ?></div><?php
		                            }

									$sql = "SELECT id, question, choice1, choice2, choice3, choice4 FROM questions WHERE subject_id = '$sid' AND id NOT IN (SELECT questions_id FROM narrative_questions) ORDER BY RAND() LIMIT $limit";
								    $stmt = mysqli_stmt_init($conn);
								    mysqli_stmt_prepare($stmt, $sql);
								    mysqli_stmt_execute($stmt);
								    $result = mysqli_stmt_get_result($stmt);
								    $num = 0;
								    while ($row = mysqli_fetch_assoc($result)) {
								    	$num++;
		                                $question=$row['question'];
		                                $choice1=$row['choice1'];
		                                $choice2=$row['choice2'];
		                                $choice3=$row['choice3'];
		                                $choice4=$row['choice4'];
		                                ?>
		                                    <div class="items">
		                                        <div>
		                                            <h4><?php echo $num . ". " . $question; ?></h4>
		                                        </div>
		                                        <div class="choicecontainer">
		                                            <div>
		                                            	<input type="radio" name="<?php echo $row['id']; ?>" value="<?php echo $choice1; ?>">
		                                            	<label><?php echo $choice1; ?></label>
		                                            </div>
		                                            <div>
		                                            	<input type="radio" name="<?php echo $row['id']; ?>" value="<?php echo $choice2; ?>">
		                                            	<label><?php echo $choice2; ?></label>
		                                            </div>
		                                            <div>
		                                            	<input type="radio" name="<?php echo $row['id']; ?>" value="<?php echo $choice3; ?>">
		                                            	<label><?php echo $choice3; ?></label>
		                                            </div>
		                                            <div>
		                                            	<input type="radio" name="<?php echo $row['id']; ?>" value="<?php echo $choice4; ?>">
		                                            	<label><?php echo $choice4; ?></label>
		                                            </div>
		                                        </div>
		                                    </div>
		                                <?php
	    							}

	    						?>
	    						<button type="button" onclick="submitForm()">SUBMIT</button>
    						</form>
						</div>
						<script>
						    window.addEventListener("beforeunload", function(e) {
						    	e.preventDefault();
						    	e.returnValue = "";
						    });
						    if (localStorage.getItem('time') === null) {
						    	localStorage.setItem('time', <?php echo $time; ?>);
						    }

						    var time = localStorage.getItem('time');
						    var totaltime = time * 60000;
						    var thistime;

						    var stopTime = new Date().getTime() + totaltime;

							var x = setInterval(function() {
								var now = new Date().getTime();
							  	var distance = stopTime - now;

							  	var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
								var seconds = Math.floor((distance % (1000 * 60)) / 1000);
								    
								// Output the result in an element with id="demo"
								document.getElementById("counter").innerHTML = minutes + "m " + seconds + "s ";
								thistime = (distance / 60000);
								localStorage.setItem('time', thistime);

								if (distance <= 0) {
								    clearInterval(x);
								    localStorage.removeItem('time');
								    document.getElementById('questionform').submit();
								}

							}, 1000);

							function submitForm() {
								clearInterval(x);
								localStorage.removeItem('time');
								document.getElementById('questionform').submit();
							}
						</script>
					<?php

				}
				else if (!isset($_GET['subject']) || empty($_GET['subject'])) {
					?>
						<div class="welcome" style="width: 80%;">
							<h2 style="margin-top: 4em;">HELLO <?php echo strtoupper($efirst); ?>!</h2>
							<p style="margin: 0;">Welcome to the Junior High Online Entrance Examination of Andres Soriano Colleges of Bislig.</p>
							<p style="margin: 0;">To start, please select a subject on the left.</p>
							<br>
							<h4>Good luck and God bless!</h4>
						</div>
					<?php
				}
				else if (isset($_GET['subject']) && !empty($_GET['subject'])) {
					$sid = $_GET['subject'];
					$sql = "SELECT exam_result.correct_answers, subject.items, subject.passing_rate, subject.description FROM exam_result INNER JOIN subject ON exam_result.subject_id = subject.id WHERE exam_result.examinee_id = '$eid' AND exam_result.subject_id = '$sid'";
				    $stmt = mysqli_stmt_init($conn);
				    mysqli_stmt_prepare($stmt, $sql);
				    mysqli_stmt_execute($stmt);
				    $result = mysqli_stmt_get_result($stmt);

				    if ($row = mysqli_fetch_assoc($result)) {
				    	$rating = $row['correct_answers'] / $row['items'] * 100;
				    	?>
					    	<div class="scoreContainer">
					    		<table>
					    			<tr>
					    				<td><h3>Rating:</h3></td>
					    				<td>&nbsp;&nbsp;&nbsp;</td>
					    				<td><h3><?php echo round($rating, 2) . "%"; ?></h3></td>
					    			</tr>
					    		</table>
					    	</div>
				    	<?php
				    }
				}
			?>

		</div>

	</body>
</html>

