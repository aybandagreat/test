<?php

	if (!isset($_POST['studentLogin'])) {
		header("Location: student-login.php?error=invalidaccess");
		exit();
	}
	else if (isset($_POST['studentLogin'])) {
		
		if (empty($_POST['email']) || empty($_POST['password']) || empty($_POST['code'])) {
			header("Location: student-login.php?error=emptyinputs");
			exit();
		}
		else if (!empty($_POST['email']) && !empty($_POST['password']) && !empty($_POST['code'])) {
			
			require '../dbconnect.php';

			//assign user input into variables with a trim PHP function to remove white spaces before and after the input
			$email = trim($_POST['email']);
			$password = $_POST['password'];
			$code = $_POST['code'];

			//select all table data that has a username of "admin"
			$sql = "SELECT * FROM examinee WHERE email = ?";
			$stmt = mysqli_stmt_init($conn);

			if (!mysqli_stmt_prepare($stmt, $sql)) {
				header("Location: student-login.php?error=sqlerror");
				exit();
			}
			else {
				mysqli_stmt_bind_param($stmt, "s", $email);
				mysqli_stmt_execute($stmt);
				mysqli_stmt_store_result($stmt);
				$resultcheck = mysqli_stmt_num_rows($stmt);

				if ($resultcheck == 0) {
					header("Location: student-login.php?error=examineedoesnotexist");
					exit();
				}
				else if ($resultcheck > 0) {
					$sql = "SELECT * FROM examinee WHERE email = ?";
					$stmt = mysqli_stmt_init($conn);

					if (!mysqli_stmt_prepare($stmt, $sql)) {
						header("Location: student-login.php?error=sqlerror");
						exit();
					}
					else {
						mysqli_stmt_bind_param($stmt, "s", $email);
						mysqli_stmt_execute($stmt);
						$result = mysqli_stmt_get_result($stmt);

						if ($row = mysqli_fetch_assoc($result)) {

							$checkpassword = password_verify($password, $row['password']);

							if ($checkpassword == false || $code != $row['token']) {
								header("Location: student-login.php?error=wrongcredentials");
								exit();
							}
							else if ($checkpassword == true) {
								session_start();
								session_id();
								$_SESSION['examineeid'] = $row['id'];
								header("Location: examinee-page.php?msg=loginsuccess");
								exit();
							}
						}
					}
				}
			}
		}
	}