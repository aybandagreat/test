<?php

	/*$sql = "SELECT * FROM questions 
	INNER JOIN subject ON questions.subject_id = '$sid' 
	ORDER BY RAND() 
	LIMIT subject.items";*/
	$sql = "SELECT items FROM subject WHERE id = '$sid'";
    $stmt = mysqli_stmt_init($conn);
    mysqli_stmt_prepare($stmt, $sql);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
    	$limit = intval($row['items']);
    }



	$sql = "SELECT * FROM questions WHERE subject_id = '$sid' ORDER BY RAND() LIMIT $limit";
    $stmt = mysqli_stmt_init($conn);
    mysqli_stmt_prepare($stmt, $sql);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    while ($row = mysqli_fetch_assoc($result)) {
    	?>
    		<div class="questionitems">
    			<?php echo $row['question']; ?>
    		</div>
    	<?php
    }