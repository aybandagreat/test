<?php

	if (session_status() == PHP_SESSION_NONE) {
		session_start();
		$sid = $_SESSION['subject'];
		unset($_SESSION['subject']);

		$examinee = $_SESSION['examineeid'];
		$answers = $_POST;
		$correctCount = 0;

		var_dump($_POST);

		require '../dbconnect.php';

		foreach ($answers as $questionid => $answer) {

			$firstid = $questionid;

			$sql = "INSERT INTO exam_answers (examinee_id, question_id, answer) VALUES (?, ?, ?)";
			$stmt = mysqli_stmt_init($conn);

			if (!mysqli_stmt_prepare($stmt, $sql)) {
				header("Location: examinee-page.php?error=sqlerror");
				exit();
			}
			else {
				mysqli_stmt_bind_param($stmt, "iis", $examinee, $questionid, $answer);
				mysqli_stmt_execute($stmt);
			}
			
			$sql = "SELECT answer FROM questions WHERE id = ?";
			$stmt = mysqli_stmt_init($conn);

			if (!mysqli_stmt_prepare($stmt, $sql)) {
				header("Location: examinee-page.php?error=sqlerror");
				exit();
			}
			else {
				mysqli_stmt_bind_param($stmt, "i", $questionid);
				mysqli_stmt_execute($stmt);
				$result = mysqli_stmt_get_result($stmt);

				if ($row = mysqli_fetch_assoc($result)) {
					if ($row['answer'] == $answer) {
						$correctCount++;
					}
				}
			}
		}

		$sql = "SELECT id FROM subject WHERE id IN (SELECT subject_id FROM questions WHERE id = '$firstid')";
		$stmt = mysqli_stmt_init($conn);

		mysqli_stmt_prepare($stmt, $sql);
		mysqli_stmt_execute($stmt);
		$result = mysqli_stmt_get_result($stmt);

		if ($row = mysqli_fetch_assoc($result)) {
			$subjectid = $row['id'];
		}

		$sql = "INSERT INTO exam_result (examinee_id, subject_id, correct_answers) VALUES (?, ?, ?)";
		$stmt = mysqli_stmt_init($conn);

		if (!mysqli_stmt_prepare($stmt, $sql)) {
			header("Location: examinee-page.php?error=sqlerror");
			exit();
		}
		else {
			mysqli_stmt_bind_param($stmt, "iis", $examinee, $subjectid, $correctCount);
			mysqli_stmt_execute($stmt);
			header("Location: examinee-page.php?subject=" . $sid);
			exit();
		}
	}

?>