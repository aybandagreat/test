<?php
	if (session_status() == PHP_SESSION_NONE) {
		session_start();
	}
	if (isset($_SESSION['subject'])) {
		header("Location: examinee-page.php");
		exit();
	}
	

	if (!isset($_POST['startbutton'])) {
		header("Location: examinee-page.php?error=invalidaccess");
		exit();
	}
	else if (isset($_POST['startbutton'])) {
		
		if (empty($_POST['subjectid']) || empty($_POST['examineeid'])) {
			// code...
		}
		else if (!empty($_POST['subjectid']) && !empty($_POST['examineeid'])) {

			$sid = $_POST['subjectid'];
			$eid = $_POST['examineeid'];

			require '../dbconnect.php';

			$sql = "SELECT * FROM examinee WHERE id = ?";
            $stmt = mysqli_stmt_init($conn);

            if (!mysqli_stmt_prepare($stmt, $sql)) {
                header("Location: examinee-page.php?error=sqlerror");
                exit();
            }
            else {
                mysqli_stmt_bind_param($stmt, "i", $eid);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_store_result($stmt);

                $resultcheck = mysqli_stmt_num_rows($stmt);

                if ($resultcheck == 0) {
                    header("Location: examinee-page.php?error=examineedoesnotexist");
                    exit();
                }
                else if ($resultcheck == 1) {
                	
                	$sql = "SELECT * FROM subject WHERE id = ?";
		            $stmt = mysqli_stmt_init($conn);

		            if (!mysqli_stmt_prepare($stmt, $sql)) {
		                header("Location: examinee-page.php?error=sqlerror");
		                exit();
		            }
		            else {
		                mysqli_stmt_bind_param($stmt, "i", $sid);
		                mysqli_stmt_execute($stmt);
		                mysqli_stmt_store_result($stmt);

		                $resultcheck = mysqli_stmt_num_rows($stmt);

		                if ($resultcheck == 0) {
		                    header("Location: examinee-page.php?error=subjectdoesnotexist");
		                    exit();
		                }
		                else if ($resultcheck == 1) {
		                	
		                	$sql = "SELECT * FROM questions WHERE subject_id = ?";
		                	$stmt = mysqli_stmt_init($conn);
		                	mysqli_stmt_prepare($stmt, $sql);
			                mysqli_stmt_bind_param($stmt, "i", $sid);
			                mysqli_stmt_execute($stmt);
			                mysqli_stmt_store_result($stmt);

			                $resultcheck = mysqli_stmt_num_rows($stmt);

		                	if ($resultcheck == 0) {
		                		header("Location: examinee-page.php?error=noquestionsyet");
					            exit();
		                	}
		                	else if ($resultcheck > 0) {
		                		$sql = "SELECT attempt FROM exam_attempt WHERE subject_id = ? AND examinee_id = ?";
					            $stmt = mysqli_stmt_init($conn);

					            if (!mysqli_stmt_prepare($stmt, $sql)) {
					                header("Location: examinee-page.php?error=sqlerror");
					                exit();
					            }
					            else {
					                mysqli_stmt_bind_param($stmt, "ii", $sid, $eid);
					                mysqli_stmt_execute($stmt);
					                $results = mysqli_stmt_get_result($stmt);

					                if ($row = mysqli_fetch_assoc($results)) {
					                	$attempt = $row['attempt'];
					                    if ($attempt == 0) {
					                    	$update = 1;
					                    	$sql = "UPDATE exam_attempt SET attempt = ? WHERE subject_id = ? AND examinee_id = ?";
								            $stmt = mysqli_stmt_init($conn);
								            mysqli_stmt_prepare($stmt, $sql);
							                mysqli_stmt_bind_param($stmt, "iii", $update, $sid, $eid);
							                mysqli_stmt_execute($stmt);

							                if (session_status() == PHP_SESSION_NONE) {
							                	session_start();
							                }

							                $_SESSION['subject'] = $sid;

							                header("Location: examinee-page.php");
					                		exit();
					                    }
					                    else if ($attempt == 1) {
					                    	header("Location: examinee-page.php?error=alreadyanswered");
					                		exit();
					                    }
					                    else {
					                    	header("Location: examinee-page.php?error=sqlerror");
					                		exit();
					                    }
					                }
					            }
		                	}

		                }
		            }	
                }
            }
		}
	}