<?php
	if (session_status() == PHP_SESSION_NONE) {
		session_start();
	}
	if (isset($_SESSION['examineeid']) && !empty($_SESSION['examineeid'])) {
		header("Location: examinee-page.php");
		exit();
	}
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="student-login-style.css">
		<title>Entrance Exam | Student Login</title>
	</head>
	<body>
		<div class="admin-login">
			<div>
				<form method="POST" action="student-login.sql.php">
					<h4>STUDENT LOGIN</h4>
					<div>
						<label for="code">Access Code</label>
						<input type="number" name="code" id="code" required>
					</div>
					<div>
						<label for="email">Email</label>
						<input type="email" name="email" id="email" required>
					</div>
					<div>
						<label for="password">Password</label>
						<input type="password" name="password" id="password" required>
					</div>
					<div>
						<input type="checkbox" onclick="showPassword(this)">
						<label for="password">Show Password</label>
					</div>
					<?php

						if (isset($_GET['error']) && !empty($_GET['error'])) {
							$err = $_GET['error'];
							?><span id="errmsg"><?php
							if ($err == 'emaildoesnotexist') {
								echo "The email you've entered does not exist.";
							}
							else if ($err == 'wrongcredentials') {
								echo "Oops, you've entered an incorrect credential.";
							}
							?></span><?php
						}

					?>
					<div class="button-container">
						<button type="reset">CLEAR</button>
						<button type="submit" name="studentLogin">LOGIN</button>
					</div>
					<a href="../admin-login.php" style="color: black;">Login as admin</a>
				</form>
			</div>
			<div class="title"><h2>ENTRANCE EXAMINATION</h2></div>
		</div>
		<script>
		    var passwordinput = document.getElementById('password');
		    function showPassword(checkbox) {
		        if (checkbox.checked) {
		            passwordinput.type = "text";
		        }
		        else {
		            passwordinput.type = "password";
		        }
		    }
		</script>
	</body>
</html>


