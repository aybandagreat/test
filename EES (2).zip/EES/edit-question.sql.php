<?php

	if (!isset($_POST['question-button'])) {
		header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=unauthorized");
        exit();
	}
	else if (isset($_POST['question-button'])) {
		
		if (empty($_POST['editQuestion']) || empty($_POST['editA']) || empty($_POST['editB']) || empty($_POST['editC']) || empty($_POST['editD']) || empty($_POST['questionId'])) {
			header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=emptyinputs");
        	exit();
		}
		else if (!empty($_POST['editQuestion']) && !empty($_POST['editA']) && !empty($_POST['editB']) && !empty($_POST['editC']) && !empty($_POST['editD']) && !empty($_POST['questionId'])) {

			require 'dbconnect.php';

            $sid = $_POST['subjectid'];
			$id = $_POST['questionId'];
			$question = $_POST['editQuestion'];
			$editA = $_POST['editA'];
			$editB = $_POST['editB'];
			$editC = $_POST['editC'];
			$editD = $_POST['editD'];
			
			$sql = "SELECT * FROM questions WHERE id = ?";
            $stmt = mysqli_stmt_init($conn);

            if (!mysqli_stmt_prepare($stmt, $sql)) {
                header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=sqlerror");
                exit();
            }
            else {
                mysqli_stmt_bind_param($stmt, "i", $id);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_store_result($stmt);

                $resultcheck = mysqli_stmt_num_rows($stmt);

                if ($resultcheck == 0) {
                    header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=coursedoesnotexist");
                    exit();
                }
                else {

                    if (isset($_POST['editAnswer']) && !empty($_POST['editAnswer'])) {
                        $answer = $_POST['editAnswer'];
                        switch ($answer[$i]) {
                            case 1:
                                $answerChoice = $editA;
                                break;
                            case 2:
                                $answerChoice = $editB;
                                break;
                            case 3:
                                $answerChoice = $editC;
                                break;
                            case 4:
                                $answerChoice = $editD;
                                break;
                            default:
                                $answerChoice = "";
                                break;
                        }
                        $sql = "UPDATE questions SET question = ?, choice1 = ?, choice2 = ?, choice3 = ?, choice4 = ?, answer = ? WHERE id = ?";
                    }
                    else {
                        $sql = "UPDATE questions SET question = ?, choice1 = ?, choice2 = ?, choice3 = ?, choice4 = ? WHERE id = ?";
                    }
                    
                    $stmt = mysqli_stmt_init($conn);

                    if (!mysqli_stmt_prepare($stmt, $sql)) {
                        header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=sqlerror");
                        exit();
                    }
                    else {
                    	if (isset($_POST['editAnswer']) && !empty($_POST['editAnswer'])) {
                            mysqli_stmt_bind_param($stmt, "ssssssi", $question, $editA, $editB, $editC, $editD, $answerChoice, $id);
                        }
                        else {
                            mysqli_stmt_bind_param($stmt, "sssssi", $question, $editA, $editB, $editC, $editD, $id);
                        }
                        mysqli_stmt_execute($stmt);
                        header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?msg=editquestionsuccess&course=".$sid);
                        exit();
                    }
                }
            }
		}
	}