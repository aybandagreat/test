<?php if (session_status() === PHP_SESSION_NONE) {
    session_start();
} ?>

<?php
    if (isset($_SESSION['admin']) && !empty($_SESSION['admin'])) {
        $adminid = $_SESSION['adminid'];
        $admin = $_SESSION['admin'];
        require 'dbconnect.php';
    }
    else if (!isset($_SESSION['admin']) || empty($_SESSION['admin'])) {
        header("Location: admin-login.php?error=invalidaccess");
        exit();
    }
?>

<div class="sidemenu">

    <div class="items-container">
        <div class="label">
            <h3>Results</h3>
            <hr>
        </div>
        <div class="items"><a href="admin.php">Exam Results</a></div>
        <div class="items"><a href="rankings.php">Rankings</a></div>

        <div class="label">
            <h3>Examinees</h3>
            <hr>
        </div>
        <div class="items" onclick="showTokenModal()">Add Examinee</div>
        <div class="items"><a href="manage-examinee.php">Examinees</a></div>

        <div class="label">
            <h3>Questions</h3>
            <hr>
        </div>
        <div class="items"><a href="add-question.php">Add Question</a></div>
        <div class="items"><a href="add-narrative.php" style="text-align: center;">Add Narrative Question</a></div>
        <div class="items"><a href="questions.php">Questions</a></div>

        <div class="label">
            <h3>Subjects</h3>
            <hr>
        </div>
        <div class="items" onclick="showCourseModal()">Add Subject</div>
        <div class="items"><a href="subjects.php">Subjects</a></div>
    </div>

    <div class="logout-container">
        <div class="items _logout"><a href="logout.sql.php">Logout</a></div>
    </div>

</div>

 <div class="token-modal" id="tokenModal">
    <div>
        <form action="new-examinee.sql.php" method="POST">
            <h4>ADD NEW EXAMINEE</h4>
            <div>
                <label for="firstname">Firstname</label>
                <input type="text" name="newFirstname" placeholder="Juan" id="firstname" required pattern="[a-zA-Z\s ]{0,30}" title="Must not contain more than 30 characters and must not contain numbers.">
            </div>
            <div>
                <label for="lastname">Lastname</label>
                <input type="text" name="newLastname" placeholder="Dela Cruz" id="lastname" required pattern="[a-zA-Z\s ]{0,30}" title="Must not contain more than 30 characters and must not contain numbers.">
            </div>
            <div>
                <label for="address">Address</label>
                <input type="text" name="newAddress" placeholder="Address" required id="address">
            </div>
            <div>  
                <label for="birthdate">Birthdate</label>
                <input type="date" name="newBirthdate" id="birthdate" required>
            </div>
            <div>  
                <label for="email">Email</label>
                <input type="email" name="newEmail" placeholder="delacruzjuan@gmail.com" id="email" required>
            </div>
            <div>  
                <label for="password">Password</label>
                <input type="password" name="newPassword" id="password" required>
            </div>
            <div>
                <input type="checkbox" onclick="showPassword(this)">
                <label>Show Password</label>
            </div>
            <div class="button-container">
                <button type="button" onclick="closeModal()">CANCEL</button>
                <button type="submit" name="add-button">ADD</button>
            </div>
        </form>
    </div>
</div>

<div class="token-modal" id="editModal">
    <div>
        <form action="edit-examinee.sql.php" method="POST">
            <h4>EDIT EXAMINEE</h4>
            <input type="hidden" name="examineeId" id="editId">
            <input type="hidden" name="examineeToken" id="editToken">
            <div>
                <label for="editFirstname">Firstname</label>
                <input type="text" name="newFirstname" placeholder="Juan" id="editFirstname" required pattern="[a-zA-Z\s ]{0,30}" title="Must not contain more than 30 characters and must not contain numbers." style="text-transform: capitalize;">
            </div>
            <div>
                <label for="editLastname">Lastname</label>
                <input type="text" name="newLastname" placeholder="Dela Cruz" id="editLastname" required pattern="[a-zA-Z\s ]{0,30}" title="Must not contain more than 30 characters and must not contain numbers." style="text-transform: capitalize;">
            </div>
            <div>
                <label for="editAddress">Address</label>
                <input type="text" name="newAddress" placeholder="Address" id="editAddress" required>
            </div>
            <div>  
                <label for="editBirthdate">Birthdate (dd/mm/yyyy)</label>
                <input type="date" name="newBirthdate" id="editBirthdate" required>
            </div>
            <div>
                <input type="checkbox" name="changeToken"><label> Change Code</label>
            </div>
            <div class="button-container">
                <button type="button" onclick="closeModal()">CANCEL</button>
                <button type="submit" name="edit-button">SAVE</button>
            </div>
        </form>
    </div>
</div>

<div class="token-modal" id="courseModal">
    <div>
        <form action="add-subject.sql.php" method="POST">
            <h4>ADD NEW SUBJECT</h4>
            <div>
                <label for="subjectName">Subject Description</label>
                <input type="text" name="subjectName" placeholder="Physics" id="subjectName" required pattern="{0,64}" title="Must NOT contain more than 32 characters." style="text-transform: capitalize;">
            </div>
            <div>
                <label for="subjectItems">Number of Items</label>
                <input type="text" name="subjectItems" placeholder="50" id="subjectItems" required pattern="[0-9\s ]{0,5}" title="Must NOT contain more than 5 characters and must contain numbers only." style="text-transform: capitalize;">
                <label style="font-size: .9em;">Note: Limits the number of questions displayed to students*</label>
            </div>
            <div>
                <label for="subjectTime">Examination Time Limit (Minutes)</label>
                <input type="text" name="subjectTime" placeholder="40" id="subjectTime" required pattern="[0-9\s ]{0,5}" title="Must NOT contain more than 5 characters and must contain numbers only." list="minutesSelection1">
            </div>
            <div>
                <label for="subjectPassing">Passing Rate (Percent)</label>
                <input type="text" name="subjectPassing" placeholder="60" id="subjectPassing" required pattern="[0-9\s ]{0,5}" title="Must NOT contain more than 5 characters and must contain numbers only." list="passingRate1">
            </div>
            <div class="button-container">
                <button type="button" onclick="closeModal()">CANCEL</button>
                <button type="submit" name="add-subject-button">ADD</button>
            </div>

            <datalist id="minutesSelection1">
                <option>10</option>
                <option>20</option>
                <option>30</option>
                <option>40</option>
                <option>50</option>
                <option>60</option>
            </datalist>

            <datalist id="passingRate1">
                <option>60</option>
                <option>70</option>
                <option>80</option>
                <option>90</option>
                <option>100</option>
            </datalist>
        </form>
    </div>
</div>

<div class="token-modal" id="editCourseModal">
    <div>
        <form action="edit-subject.sql.php" method="POST">
            <h4>EDIT EXAM COURSE</h4>
            <input type="hidden" name="subjectId" id="editSubjectId">
            <div>
                <label for="editSubjectName">Subject Description</label>
                <input type="text" name="editSubjectName" placeholder="Physics" id="editSubjectName" required pattern="{0,64}" title="Must NOT contain more than 32 characters." style="text-transform: capitalize;">
            </div>
            <div>
                <label for="editSubjectItems">Number of Items</label>
                <input type="text" name="editSubjectItems" placeholder="50" id="editSubjectItems" required pattern="[0-9\s ]{0,5}" title="Must NOT contain more than 5 characters and must contain numbers only." style="text-transform: capitalize;">
            </div>
            <div>
                <label for="editSubjectTime">Examination Time Limit (Minutes)</label>
                <input type="text" name="editSubjectTime" placeholder="40" id="editSubjectTime" required pattern="[0-9\s ]{0,5}" title="Must NOT contain more than 5 characters and must contain numbers only." list="minutesSelection">
            </div>
            <div>
                <label for="editSubjectPassing">Passing Rate (Percent)</label>
                <input type="text" name="editSubjectPassing" placeholder="60" id="editSubjectPassing" required pattern="[0-9\s ]{0,5}" title="Must NOT contain more than 5 characters and must contain numbers only." list="passingRate">
            </div>
            <div class="button-container">
                <button type="button" onclick="closeModal()">CANCEL</button>
                <button type="submit" name="edit-subject-button">SAVE</button>
            </div>

            <datalist id="minutesSelection">
                <option>10</option>
                <option>20</option>
                <option>30</option>
                <option>40</option>
                <option>50</option>
                <option>60</option>
            </datalist>

            <datalist id="passingRate">
                <option>60</option>
                <option>70</option>
                <option>80</option>
                <option>90</option>
                <option>100</option>
            </datalist>
        </form>
    </div>
</div>


<?php

    if (isset($_GET['msg'])) {
       if ($_GET['msg'] == 'success'){
            ?>
            <div class="error-modal blur" id="errorModal">
                <div>
                    <h4>SUCCESSFULLY ADDED EXAMINEE</h4>
                    <p>Email: <strong><?php echo $_GET['email'];?></strong></p>
                    <p>Examination Code: <strong><?php echo $_GET['token'];?></strong></p>
                    <div class="button-container">
                        <button type="button" onclick="closeError()">CLOSE</button>
                        <button type="button" onclick="openTokenModal()">ADD NEW</button>
                    </div>
                </div>
            </div>
            <?php
       }
       else if ($_GET['msg'] == 'editsuccess') {
            ?>
            <div class="error-modal" id="errorModal">
                <div>
                    <h4>SUCCESSFULLY EDITED EXAMINEE</h4>
                    <p>Firstname: <strong><?php echo strtoupper($_GET['fname']);?></strong></p>
                    <p>Lastname: <strong><?php echo strtoupper($_GET['lname']);?></strong></p>
                    <p>Examination Code: <strong><?php echo $_GET['token'];?></strong></p>
                    <div class="button-container">
                        <button type="button" onclick="closeError()">CLOSE</button>
                        <button type="button" onclick="openTokenModal()">ADD NEW</button>
                    </div>
                </div>
            </div>
            <?php
       }
       else if ($_GET['msg'] == 'editquestionsuccess') {
            ?>
                <div class="error-modal" id="errorModal">
                    <div>
                        <h4>SUCCESSFULLY EDITED QUESTION</h4>
                        <div class="button-container" style="margin-top: 2em;">
                            <button type="button" onclick="closeError()" style="margin: 0 auto;">CLOSE</button>
                        </div>
                    </div>
                </div>
            <?php
       }
    }

?>

<script>
    const modal = document.getElementById('tokenModal');
    const errormodal = document.getElementById('errorModal');
    const editmodal = document.getElementById('editModal');
    const coursemodal = document.getElementById('courseModal');
    const editcourse = document.getElementById('editCourseModal');

    function showTokenModal() {
        modal.classList.add('visible');
    }
    function showCourseModal() {
        coursemodal.classList.add('visible');
    }

    function closeError() {
        errormodal.style.display = 'none';
    }
    function openTokenModal() {
        errormodal.style.display = 'none';
        modal.classList.add('visible');
    }

    function closeModal() {
        modal.classList.remove('visible');
        editmodal.classList.remove('visible');
        coursemodal.classList.remove('visible');
        editcourse.classList.remove('visible');
    }
</script>

<script>
    var passwordinput = document.getElementById('password');
    function showPassword(checkbox) {
        if (checkbox.checked) {
            passwordinput.type = "text";
        }
        else {
            passwordinput.type = "password";
        }
    }
</script>