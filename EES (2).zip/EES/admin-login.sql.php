<?php

	if (!isset($_POST['adminLogin'])) {
		header("admin-login.php?error=invalidaccess");
		exit();
	}
	else if (isset($_POST['adminLogin'])) {

		if (empty($_POST['adminUsername']) || empty($_POST['adminPassword'])) {
			$_SESSION['error'] = "emptyinputs";
			header("admin-login.php");
			exit();
		}
		else if (!empty($_POST['adminUsername']) && !empty($_POST['adminPassword'])) {

			require 'dbconnect.php';

			//assign user input into variables with a trim PHP function to remove white spaces before and after the input
			$uname = trim($_POST['adminUsername']);
			$pass = trim($_POST['adminPassword']);


			$sql = "SELECT * FROM admin";
			$stmt = mysqli_stmt_init($conn);
			mysqli_stmt_prepare($stmt, $sql);
			mysqli_stmt_execute($stmt);
			mysqli_stmt_store_result($stmt);
			$resultcheck = mysqli_stmt_num_rows($stmt);

			$adminpassword = password_hash("adminz6f90y", PASSWORD_DEFAULT);
			$adminusername = "admin";

			if ($resultcheck == 0) {
				$sql2 = "INSERT INTO admin (username, password) VALUES (?, ?)";
				$stmt2 = mysqli_stmt_init($conn);
				mysqli_stmt_prepare($stmt2, $sql2);
				mysqli_stmt_bind_param($stmt2, "ss", $adminusername, $adminpassword);
				mysqli_stmt_execute($stmt2);
			}
			

			//select all table data that has a username of "admin"
			$sql = "SELECT username FROM admin WHERE username=?";
			$stmt = mysqli_stmt_init($conn);

			if (!mysqli_stmt_prepare($stmt, $sql)) {
				//runs this code if there is a db connection error
				header("Location: admin-login.php?error=sqlerror");
				exit();
			}


			//goes here if db connection is good
			else {
				
				//execute the query
				mysqli_stmt_bind_param($stmt, "s", $uname);
				mysqli_stmt_execute($stmt);

				//store the result
				mysqli_stmt_store_result($stmt);
				$resultcheck = mysqli_stmt_num_rows($stmt);

				//check if there is data found with the username "admin"

				if ($resultcheck == 0) {
					//go back to admin login page if username does not exist
					header("Location: admin-login.php?error=invalid");
					exit();
				}

				//run this code if there is username "admin"
				else if ($resultcheck > 0) {

					//select again from admin table with the username "admin"
					$sql = "SELECT * FROM admin WHERE username=?";
					$stmt = mysqli_stmt_init($conn);

					if (!mysqli_stmt_prepare($stmt, $sql)) {
						header("Location: admin-login.php?error=sqlerror");
						exit();
					}

					else {
						mysqli_stmt_bind_param($stmt, "s", $uname);
						mysqli_stmt_execute($stmt);

						//gets the result of the select query
						$result = mysqli_stmt_get_result($stmt);

						//associates the retrieved data into a $row variable which can be used later to store into a session
						if ($row = mysqli_fetch_assoc($result)) {

							//password_verify is a PHP function that checks if the entered password is the same with the saved hashed password
							$pwdCheck = password_verify($pass, $row['password']);

							if ($pwdCheck == false) {
								//go back to admin login page if password is incorrect
								header("Location: admin-login.php?error=invalid&username=".$uname);
								exit();
							}

							//run this code if password is correct
							else if ($pwdCheck == true) {

								//storing retrieved data (admin: id & username) into a session variable
								session_start();
								session_id();

								$_SESSION['adminid'] = $row['id'];
								$_SESSION['admin'] = $row['username'];

								//go to admin main page and pass message that logging in is successful
								header("Location: admin.php?msg=loginsuccess");
								exit();
							}
						}
					}
				}
			}
		}
	}
	else {
		header("admin-login.php");
		exit();
	}