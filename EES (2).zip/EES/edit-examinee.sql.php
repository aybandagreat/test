<?php
    if (isset($_POST['edit-button'])) {
        
        if (empty($_POST['newFirstname']) || empty($_POST['newLastname']) || empty($_POST['newAddress']) || empty($_POST['newBirthdate'])) {
             header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=emptyinputs");
            exit();
        }
        else if (!empty($_POST['newFirstname']) && !empty($_POST['newLastname']) && !empty($_POST['newAddress']) && !empty($_POST['newBirthdate'])) {

            require 'dbconnect.php';

            $fname = strtolower(trim($_POST['newFirstname']));
            $lname = strtolower(trim($_POST['newLastname']));
            $address = trim($_POST['newAddress']);
            $bdate = $_POST['newBirthdate'];
            $savedId = $_POST['examineeId'];
            $savedToken = $_POST['examineeToken'];

            $token = rand(000001, 999999);
            $existingToken = true;

            
            $sql = "SELECT * FROM examinee WHERE id=? AND token=?";
            $stmt = mysqli_stmt_init($conn);

            if (!mysqli_stmt_prepare($stmt, $sql)) {
                 header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=sqlerror");
                exit();
            }
            else {
                mysqli_stmt_bind_param($stmt, "ii", $savedId, $savedToken);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_store_result($stmt);

                $resultcheck = mysqli_stmt_num_rows($stmt);

                if ($resultcheck == 0) {
                    header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=examineedoesnotexist");
                    exit();
                }
                else {

                    //checks if token exists & create a new one until generated token is unique
                    while ($existingToken == true) {
                        $sql = "SELECT token FROM examinee WHERE token=?";
                        $stmt = mysqli_stmt_init($conn);
                        mysqli_stmt_prepare($stmt, $sql);
                        mysqli_stmt_bind_param($stmt, "i", $token);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_store_result($stmt);
                        $resultcheck = mysqli_stmt_num_rows($stmt);

                        if ($resultcheck > 0) {
                            $existingToken = true;
                            $token = rand(000001, 999999);
                        }
                        else if ($resultcheck == 0) {
                            $existingToken = false;
                        }
                    }

                    if (isset($_POST['changeToken']) || !empty($_POST['changeToken'])) {
                        $sql = "UPDATE examinee SET firstname=?, lastname=?, address=?, birthdate=?, token=? WHERE id=?";
                    }
                    else if (!isset($_POST['changeToken']) && empty($_POST['changeToken'])) {
                        $sql = "UPDATE examinee SET firstname=?, lastname=?, address=?, birthdate=? WHERE id=?";
                    }


                    $stmt = mysqli_stmt_init($conn);

                    if (!mysqli_stmt_prepare($stmt, $sql)) {
                        header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=sqlerror");
                        exit();
                    }
                    else {

                        if (isset($_POST['changeToken']) || !empty($_POST['changeToken'])) {
                            mysqli_stmt_bind_param($stmt, "ssssii", $fname, $lname, $address, $bdate, $token, $savedId);
                        }
                        else if (!isset($_POST['changeToken']) && empty($_POST['changeToken'])) {
                            mysqli_stmt_bind_param($stmt, "ssssi", $fname, $lname, $address, $bdate, $savedId);
                        }
                        mysqli_stmt_execute($stmt);

                        if (!isset($_POST['changeToken']) && empty($_POST['changeToken'])) {
                            header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?msg=editsuccess&fname=" . $fname . "&lname=" . $lname . "&token=" . $savedToken);
                        }
                        else if (isset($_POST['changeToken']) || !empty($_POST['changeToken'])) {
                            header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?msg=editsuccess&fname=" . $fname . "&lname=" . $lname . "&token=" . $token);
                        }
                        exit();
                    }
                }
            }
        }
    }
    else if (!isset($_POST['add-button'])) {
         header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=invalidaccess");
        exit();
    }
    else {
        header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0]);
        exit();
    }