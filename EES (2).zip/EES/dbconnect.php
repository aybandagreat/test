<?php
	$servername = "localhost";
	$dbuser = "root";
	$dbpwd = "";
	$dbname = "ascb_ees";

	$conn = mysqli_connect($servername, $dbuser, $dbpwd, $dbname);

	if (!$conn) {
		die("Connection failed!".mysqli_connect_error());
	}