<?php

	if (!isset($_POST['add-exam'])) {
		header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=invalidaccess");
        exit();
	}
	else if (isset($_POST['add-exam'])) {

		if (empty($_POST['question']) || empty($_POST['choice1']) || empty($_POST['choice2']) || empty($_POST['choice3']) || empty($_POST['choice4']) || empty($_POST['answer']) || empty($_POST['subjectid'])) {
			header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=emptyinputs");
        	exit();
		}
		if (!empty($_POST['question']) && !empty($_POST['choice1']) && !empty($_POST['choice2']) && !empty($_POST['choice3']) && !empty($_POST['choice4']) && !empty($_POST['answer']) && !empty($_POST['subjectid'])) {
			
			require 'dbconnect.php';

			$subjectid = intval($_POST['subjectid']);
			$question = $_POST['question'];
			$choice1 = $_POST['choice1'];
			$choice2 = $_POST['choice2'];
			$choice3 = $_POST['choice3'];
			$choice4 = $_POST['choice4'];
			$answer = $_POST['answer'];

			$arraySize = sizeof($question);

			$sql = "SELECT * FROM subject WHERE id = ?";
            $stmt = mysqli_stmt_init($conn);

            if (!mysqli_stmt_prepare($stmt, $sql)) {
                header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=sqlerror");
                exit();
            }
            else {
                mysqli_stmt_bind_param($stmt, "i", $subjectid);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_store_result($stmt);

                $resultcheck = mysqli_stmt_num_rows($stmt);

                if ($resultcheck == 0) {
                    header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=subjectdoesnotexist");
                    exit();
                }
                else {

                	$sql = "INSERT INTO questions (subject_id, question, choice1, choice2, choice3, choice4, answer) VALUES (?, ?, ?, ?, ?, ?, ?)";
		            $stmt = mysqli_stmt_init($conn);

		            if (!mysqli_stmt_prepare($stmt, $sql)) {
		            	echo "invalid";
		                header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=sqlerror");
		                exit();
		            }
		            else {
		         		for ($i=0; $i < $arraySize; $i++) {
			            	switch ($answer[$i]) {
			            		case 1:
			            			$answerChoice = $choice1[$i];
			            			break;
		            			case 2:
			            			$answerChoice = $choice2[$i];
			            			break;
		            			case 3:
			            			$answerChoice = $choice3[$i];
			            			break;
		            			case 4:
			            			$answerChoice = $choice4[$i];
			            			break;
			            		default:
			            			$answerChoice = $choice1[$i];
			            			break;
			            	}
			            	mysqli_stmt_bind_param($stmt, "issssss", $subjectid, $question[$i], $choice1[$i], $choice2[$i], $choice3[$i], $choice4[$i], $answerChoice);
			                mysqli_stmt_execute($stmt);
			                mysqli_stmt_store_result($stmt);
			            }
			            $addItems = $_POST['addItems'];
			            header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=questionaddsuccess&course=".$subjectid."&items=".$addItems);
		                exit();
		            }

                }
            }

		}

	}