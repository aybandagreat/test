<?php
    if (isset($_POST['edit-subject-button'])) {
        
        if (empty($_POST['subjectId']) || empty($_POST['editSubjectName']) || empty($_POST['editSubjectItems']) || empty($_POST['editSubjectTime']) || empty($_POST['editSubjectPassing'])) {
             header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=emptyinputs");
            exit();
        }
        else if (!empty($_POST['subjectId']) && !empty($_POST['editSubjectName']) && !empty($_POST['editSubjectItems']) && !empty($_POST['editSubjectTime']) && !empty($_POST['editSubjectPassing'])) {

            require 'dbconnect.php';

            $id = trim($_POST['subjectId']);
            $desc = trim($_POST['editSubjectName']);
            $items = trim($_POST['editSubjectItems']);
            $time = trim($_POST['editSubjectTime']);
            $rate = trim($_POST['editSubjectPassing']);

            
            $sql = "SELECT * FROM subject WHERE id=?";
            $stmt = mysqli_stmt_init($conn);

            if (!mysqli_stmt_prepare($stmt, $sql)) {
                header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=sqlerror");
                exit();
            }
            else {
                mysqli_stmt_bind_param($stmt, "i", $id);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_store_result($stmt);

                $resultcheck = mysqli_stmt_num_rows($stmt);

                if ($resultcheck == 0) {
                    header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=coursedoesnotexist");
                    exit();
                }
                else {
                    
                    $sql = "UPDATE subject SET description=?, items=?, time_limit=?, passing_rate=? WHERE id=?";
                    $stmt = mysqli_stmt_init($conn);

                    if (!mysqli_stmt_prepare($stmt, $sql)) {
                        header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=sqlerror");
                        exit();
                    }
                    else {

                        mysqli_stmt_bind_param($stmt, "siiii", $desc, $items, $time, $rate, $id);
                        mysqli_stmt_execute($stmt);
                        header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?msg=courseeditsuccess&desc=" . $desc . "&items=" . $items . "&time=" . $time . "&rate=" . $rate);
                        exit();
                    }
                }
            }
        }
    }
    else if (!isset($_POST['edit-subject-button'])) {
        header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0] . "?error=invalidaccess");
        exit();
    }
    else {
        header("Location: " . explode("?", $_SERVER['HTTP_REFERER'])[0]);
        exit();
    }