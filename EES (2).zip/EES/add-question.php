<?php session_start(); ?>

<?php
    if (isset($_SESSION['admin']) && !empty($_SESSION['admin'])) {
        $adminid = $_SESSION['adminid'];
        $admin = $_SESSION['admin'];
        require 'dbconnect.php';
    }
    else if (!isset($_SESSION['admin']) || empty($_SESSION['admin'])) {
        header("Location: admin-login.php?error=invalidaccess");
        exit();
    }
?>


<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="admin-style.css">
        <title>Entrance Exam | Admin</title>
    </head>
    <body>
        <div class="admin-container">
            
            <?php include_once "admin-sidebar.inc.php"; ?>

            <div class="content">
                <div class="search">
                    <h4>Add Exam Questions</h4>
                   <div>
                        <label>Add questions to:</label>
                        <select onchange="(location.href = '?course=' + this.value)">
                            <?php
                                if (!isset($_GET['course'])) {
                                    ?><option selected disabled>Choose subject..</option><?php
                                }
                            ?>
                            <?php
                                $sql = "SELECT * FROM subject";
                                $stmt = mysqli_stmt_init($conn);
                                mysqli_stmt_prepare($stmt, $sql);
                                mysqli_stmt_execute($stmt);
                                $result = mysqli_stmt_get_result($stmt);

                                while ($row = mysqli_fetch_assoc($result)) {
                                    if (isset($_GET['course']) && $_GET['course'] == $row['id']) {
                                        ?><option value="<?php echo $row['id']; ?>" selected><?php echo $row['description']; ?></option><?php
                                    }
                                    else {
                                        ?><option value="<?php echo $row['id']; ?>"><?php echo $row['description']; ?></option><?php
                                    }
                                }
                            ?>
                        </select>
                   </div>
                </div>
                <div class="exam-form">
                    <form method="POST" action="add-question.sql.php">

                        <?php
                            if (isset($_GET['course']) && !empty($_GET['course'])) {
                                $id=$_GET['course'];
                                $sql = "SELECT * FROM subject WHERE id=$id";
                                $stmt = mysqli_stmt_init($conn);
                                mysqli_stmt_prepare($stmt, $sql);
                                mysqli_stmt_execute($stmt);
                                $result = mysqli_stmt_get_result($stmt);

                                if ($row = mysqli_fetch_assoc($result)) {
                                    $items=$row['items'];
                                    $course=$row['description'];
                                    $time = $row['time_limit'];
                                }

                                if (isset($_GET['items']) && !empty($_GET['items'])) {
                                    $addItems = $_GET['items'];
                                }
                                else {
                                    $addItems = 5;
                                }

                                ?>
                                <input type="hidden" name="subjectid" value="<?php echo $row['id']; ?>">
                                <input type="hidden" name="addItems" value="<?php echo $addItems; ?>">
                                <?php


                                for ($i=1; $i <= $addItems; $i++) { 
                                    ?>
                                        <div class="items">
                                            <div>
                                                <label>Question <?php echo $i; ?></label>
                                                <input type="text" name="question[]" required>
                                            </div>
                                            <div>
                                                <label>Choice A</label>
                                                <input type="text" name="choice1[]" required>
                                            </div>
                                            <div>
                                                <label>Choice B</label>
                                                <input type="text" name="choice2[]" required>
                                            </div>
                                            <div>
                                                <label>Choice C</label>
                                                <input type="text" name="choice3[]" required>
                                            </div>
                                            <div>
                                                <label>Choice D</label>
                                                <input type="text" name="choice4[]" required>
                                            </div>
                                            <div>
                                                <label>Answer</label>
                                                <select name="answer[]" required>
                                                    <option selected disabled readonly value="">Choose..</option>
                                                    <option value="1">Choice A</option>
                                                    <option value="2">Choice B</option>
                                                    <option value="3">Choice C</option>
                                                    <option value="4">Choice D</option>
                                                </select>
                                            </div>
                                        </div>
                                    <?php
                                }
                                ?><button type="submit" name="add-exam">SAVE</button><?php
                            }
                            else {
                                ?>
                                    <div class="select-modal" id="selectmodal">
                                        <div>
                                            <label>Add Questions</label>
                                            <select id="selectSubjectSubject">
                                                <option value="" selected disabled>Select a subject..</option>
                                                <?php
                                                    $sql = "SELECT * FROM subject";
                                                    $stmt = mysqli_stmt_init($conn);
                                                    mysqli_stmt_prepare($stmt, $sql);
                                                    mysqli_stmt_execute($stmt);
                                                    $result = mysqli_stmt_get_result($stmt);

                                                    while ($row = mysqli_fetch_assoc($result)) {
                                                        ?>
                                                            <option value="<?php echo $row['id']; ?>"><?php echo $row['description']; ?></option>
                                                        <?php
                                                    }
                                                ?>
                                            </select>
                                            <input type="number" list="itemsList" placeholder="Number of items" id="selectItems">
                                            <datalist id="itemsList">
                                                <option value="5">5</option>
                                                <option value="10">10</option>
                                                <option value="20">20</option>
                                                <option value="50">50</option>
                                            </datalist>
                                            <button type="button" onclick="submitUrl()">Continue</button>
                                        </div>
                                    </div>
                                <?php
                            }
                        ?>
                        <?php
                            if (isset($_GET['course'])) {
                                $sql = "SELECT * FROM questions WHERE subject_id=$id";
                                $stmt = mysqli_stmt_init($conn);
                                mysqli_stmt_prepare($stmt, $sql);
                                mysqli_stmt_execute($stmt);
                                mysqli_stmt_store_result($stmt);

                                $resultcheck = mysqli_stmt_num_rows($stmt);

                                ?>
                                    <div class="course">
                                        <span>Course: <?php echo $course; ?></span>
                                        <span>Overall added questions: <?php echo $resultcheck; ?></span>
                                        <span>Displayable items: <?php echo $items; ?></span>
                                        <span>Time allocated: <?php echo $time; ?> minutes</span>
                                    </div>
                                <?php
                            }
                        ?>

                        
                    </form>
                </div>
            </div>
        </div>
        <script>

            var courseId = document.getElementById('selectSubjectSubject');
            var items = document.getElementById('selectItems');

            function submitUrl() {
                if (courseId.value != "" && items.value != "") {
                    window.location.href = "add-question.php?course=" + courseId.value + "&items=" + items.value;
                }
                else if (courseId.value != "") {
                    window.location.href = "add-question.php?course=" + courseId.value;
                }
            }

            function showCourseEditModal(id, desc, items, time, rate) {
                editcourse.classList.toggle('visible');
                document.getElementById('editCourseId').value = id;
                document.getElementById('editCourseName').value = desc;
                document.getElementById('editCourseItems').value = items;
                document.getElementById('editCourseTime').value = time;
                document.getElementById('editCoursePassing').value = rate;
            }

            function showEditModal(id, fname, lname, add, bdate, token) {
                editmodal.classList.toggle('visible');
                document.getElementById('editId').value = id;
                document.getElementById('editFirstname').value = fname;
                document.getElementById('editLastname').value = lname;
                document.getElementById('editAddress').value = add;
                document.getElementById('editBirthdate').value = bdate;
                document.getElementById('editToken').value = token;
            }

            const selectModal = document.getElementById('selectmodal');

            window.onclick = function(event) {
                if (event.target == editmodal) {
                    editmodal.classList.remove('visible');
                }
                if (event.target == modal) {
                    modal.classList.remove('visible');
                }
                if (event.target == errormodal) {
                    errormodal.style.display = 'none';
                }
                if (event.target == editmodal) {
                    editmodal.classList.remove('visible');
                }
                if (event.target == coursemodal) {
                    coursemodal.classList.remove('visible');
                }
                if (event.target == editcourse) {
                    editcourse.classList.remove('visible');
                }
                if (event.target == selectModal) {
                    selectModal.classList.add('hide');
                }
            }
        </script>
    </body>
</html>

