<?php session_start(); ?>

<?php
    if (isset($_SESSION['admin']) && !empty($_SESSION['admin'])) {
        $adminid = $_SESSION['adminid'];
        $admin = $_SESSION['admin'];
        require 'dbconnect.php';
    }
    else if (!isset($_SESSION['admin']) || empty($_SESSION['admin'])) {
        header("Location: admin-login.php?error=invalidaccess");
        exit();
    }
?>


<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="admin-style.css">
        <title>Entrance Exam | Admin</title>
    </head>
    <body>
        <div class="admin-container">
            
            <?php include_once "admin-sidebar.inc.php"; ?>

            <div class="content">
                <div class="search">
                    <?php
                        if (!isset($_GET['examinee']) || empty($_GET['examinee'])) {
                            header("Location: manage-examinee.php");
                            exit();
                        }
                        else {
                            $eid = $_GET['examinee'];
                        }
                        $sql = "SELECT * FROM examinee WHERE id = $eid";
                        $stmt = mysqli_stmt_init($conn);
                        mysqli_stmt_prepare($stmt, $sql);
                        mysqli_stmt_execute($stmt);
                        $result = mysqli_stmt_get_result($stmt);

                        if ($row = mysqli_fetch_assoc($result)) {
                            $name = $row['lastname'] . ", " . $row['firstname'];
                            ?>
                                <h3 style="margin: 0;"><?php echo $row['token'] . " - " . strtoupper($name); ?></h3>
                            <?php
                        }
                    ?>
                </div>
                <table class="examinee-table" id="examineeTable" style="border: none;">
                    <tr>
                        <th>Subject</th>
                        <th>Score</th>
                        <th>Items</th>
                        <th>Rating</th>
                    </tr>

                    <?php
                        $totalscore = 0;
                        $totalitems = 0;
                        $sql = "SELECT * FROM subject";
                        $stmt = mysqli_stmt_init($conn);
                        mysqli_stmt_prepare($stmt, $sql);
                        mysqli_stmt_execute($stmt);
                        $result = mysqli_stmt_get_result($stmt);

                        while ($row = mysqli_fetch_assoc($result)) {
                            $subjectID = $row['id'];
                            $items = $row['items'];
                            $totalitems += $items;
                            $percent = "";

                            $sql2 = "SELECT * FROM exam_attempt WHERE subject_id = $subjectID AND examinee_id = $eid";
                            $stmt2 = mysqli_stmt_init($conn);
                            mysqli_stmt_prepare($stmt2, $sql2);
                            mysqli_stmt_execute($stmt2);
                            $result2 = mysqli_stmt_get_result($stmt2);

                            while ($row2 = mysqli_fetch_assoc($result2)) {
                                if ($row2['attempt'] == 0) {
                                    $score = "Not yet answered";
                                }
                                else if ($row2['attempt'] == 1) {
                                    $sql2 = "SELECT correct_answers FROM exam_result WHERE subject_id = $subjectID AND examinee_id = $eid";
                                    $stmt2 = mysqli_stmt_init($conn);
                                    mysqli_stmt_prepare($stmt2, $sql2);
                                    mysqli_stmt_execute($stmt2);
                                    $result2 = mysqli_stmt_get_result($stmt2);

                                    if ($row2 = mysqli_fetch_assoc($result2)) {
                                        $score = $row2['correct_answers'];
                                        $percent = $score / $items * 100;
                                    }
                                    $totalscore += $score;
                                }
                                ?>
                                <tr class="viewExmainee" onclick="viewExamineeAnswers('<?php echo $eid; ?>', '<?php echo $subjectID; ?>')">
                                    <td class="left"><?php echo $row['description']; ?></td>
                                    <td class="center"><?php echo $score; ?></td>
                                    <td class="center"><?php echo $items; ?></td>
                                    <td class="center"><?php echo $percent . "%"; ?></td>
                                </tr>
                                <?php

                            }
                        }
                        if ($totalscore != 0) {
                            $totalpercent = $totalscore / $totalitems * 100;
                        }
                        else {
                            $totalpercent = 0;
                        }
                    ?>
                    <tr style="background-color: transparent; font-weight: bold;">
                        <td class="left" style="border: none;">TOTAL</td>
                        <td class="center" style="border: none;"><?php echo $totalscore; ?></td>
                        <td class="center" style="border: none;"><?php echo $totalitems; ?></td>
                        <td class="center" style="border: none;"><?php echo round($totalpercent,1) . "%"; ?></td>
                    </tr>
                    
                </table>
            </div>
        </div>

        
        <script>
            function viewExamineeAnswers(examineeid, subjectid) {
                location.href = 'view-examinee-answers.php?examinee=' + examineeid + '&subject=' + subjectid;
            }

            function showEditModal(id, fname, lname, add, bdate, token) {
                editmodal.classList.toggle('visible');
                document.getElementById('editId').value = id;
                document.getElementById('editFirstname').value = fname;
                document.getElementById('editLastname').value = lname;
                document.getElementById('editAddress').value = add;
                document.getElementById('editBirthdate').value = bdate;
                document.getElementById('editToken').value = token;
            }

            window.onclick = function(event) {
                if (event.target == editmodal) {
                    editmodal.classList.remove('visible');
                }
                if (event.target == modal) {
                    alert("Please use the close button to close this modal.");
                }
                if (event.target == errormodal) {
                    errormodal.style.display = 'none';
                }
                if (event.target == editmodal) {
                    editmodal.classList.remove('visible');
                }
                if (event.target == coursemodal) {
                    coursemodal.classList.remove('visible');
                }
            }
        </script>

    </body>
</html>

